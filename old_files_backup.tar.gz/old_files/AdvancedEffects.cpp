#include "AdvancedEffects.h"

// Global advanced effects instance
AdvancedEffects advancedFX;

// Effect wrapper functions for FxEngine integration
void displayHDREffect() {
  advancedFX.displayHDREffect();
}

void displaySupersampledEffect() {
  advancedFX.displaySupersampledEffect();
}

void displayTimeAlphaEffect() {
  advancedFX.displayTimeAlphaEffect();
}

void displayOptimizedParticles() {
  advancedFX.displayOptimizedParticles();
}