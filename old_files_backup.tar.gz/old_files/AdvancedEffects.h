#ifndef ADVANCED_EFFECTS_H
#define ADVANCED_EFFECTS_H

#include <FastLED.h>
#include "Config.h"
#include "StripMap.h"

// External variables
extern CRGB leds[TOTAL_LEDS];
extern uint8_t angles[TOTAL_LEDS];
extern uint8_t radii[TOTAL_LEDS];
extern CRGBPalette16 currentPalette;
extern uint8_t fadeAmount;
extern uint8_t paletteSpeed;

// Advanced FastLED 3.10.0 Effects Implementation
class AdvancedEffects {
private:
  // Super-sampling buffers for smoother visuals
  static const uint8_t SUPERSAMPLE_FACTOR = 4;
  static const uint16_t SUPERSAMPLED_LEDS = TOTAL_LEDS * SUPERSAMPLE_FACTOR;
  CRGB supersampleBuffer[SUPERSAMPLED_LEDS];
  
  // HDR and 11-bit color support
  struct HDRPixel {
    uint16_t r, g, b; // 11-bit color channels
    uint8_t brightness;
  };
  HDRPixel hdrBuffer[TOTAL_LEDS];
  
  // Blur and diffusion matrices
  float blurKernel[5] = {0.06f, 0.24f, 0.40f, 0.24f, 0.06f}; // Gaussian blur
  float diffusionMatrix[TOTAL_LEDS];
  
  // Time-based transition system
  struct TimeAlpha {
    float startTime;
    float duration;
    float (*easingFunction)(float);
    bool active;
  };
  TimeAlpha timeAlpha;
  
  // Fixed-point math optimization
  typedef int32_t fixed16_t; // 16.16 fixed point
  static const int32_t FIXED_ONE = 65536;
  
public:
  
  AdvancedEffects() {
    initializeDiffusionMatrix();
    initializeTimeAlpha();
  }
  
  // Initialize diffusion matrix for light spreading
  void initializeDiffusionMatrix() {
    for (uint16_t i = 0; i < TOTAL_LEDS; i++) {
      // Create diffusion pattern based on crystal geometry
      float centerDistance = abs((int16_t)i - (int16_t)(TOTAL_LEDS / 2));
      float normalizedDistance = centerDistance / (TOTAL_LEDS / 2.0f);
      
      // More diffusion at edges, less at center
      diffusionMatrix[i] = 0.1f + (normalizedDistance * 0.4f);
    }
  }
  
  // Initialize time-based transition system
  void initializeTimeAlpha() {
    timeAlpha.startTime = 0;
    timeAlpha.duration = 1000; // 1 second default
    timeAlpha.easingFunction = easeInOutQuad;
    timeAlpha.active = false;
  }
  
  // Easing functions for smooth transitions
  static float easeInOutQuad(float t) {
    return t < 0.5f ? 2.0f * t * t : -1.0f + (4.0f - 2.0f * t) * t;
  }
  
  static float easeInOutCubic(float t) {
    return t < 0.5f ? 4.0f * t * t * t : (t - 1.0f) * (2.0f * t - 2.0f) * (2.0f * t - 2.0f) + 1.0f;
  }
  
  static float easeInOutSine(float t) {
    return -(cos(PI * t) - 1.0f) / 2.0f;
  }
  
  // Fixed-point math functions for performance
  fixed16_t floatToFixed(float f) {
    return (fixed16_t)(f * FIXED_ONE);
  }
  
  float fixedToFloat(fixed16_t f) {
    return (float)f / FIXED_ONE;
  }
  
  fixed16_t fixedMul(fixed16_t a, fixed16_t b) {
    return ((int64_t)a * b) >> 16;
  }
  
  fixed16_t fixedSin(fixed16_t angle) {
    // Fast fixed-point sine approximation
    float f = fixedToFloat(angle);
    return floatToFixed(sin(f));
  }
  
  // HDR and 11-bit color effect
  void displayHDREffect() {
    static uint32_t timeOffset = 0;
    timeOffset += paletteSpeed * 10;
    
    // Apply fade with HDR precision
    for (uint16_t i = 0; i < TOTAL_LEDS; i++) {
      hdrBuffer[i].r = (hdrBuffer[i].r * (2048 - fadeAmount)) >> 11;
      hdrBuffer[i].g = (hdrBuffer[i].g * (2048 - fadeAmount)) >> 11;
      hdrBuffer[i].b = (hdrBuffer[i].b * (2048 - fadeAmount)) >> 11;
    }
    
    // Generate HDR content
    for (uint16_t i = 0; i < TOTAL_LEDS; i++) {
      // Use fixed-point math for performance
      fixed16_t angle = floatToFixed(angles[i] * 2.0f * PI / 255.0f);
      fixed16_t time = floatToFixed(timeOffset * 0.001f);
      fixed16_t radius = floatToFixed(radii[i] / 255.0f);
      
      // Complex wave equation with HDR range
      fixed16_t wave1 = fixedSin(fixedMul(angle, floatToFixed(3.0f)) + time);
      fixed16_t wave2 = fixedSin(fixedMul(radius, floatToFixed(5.0f)) - time);
      fixed16_t combined = fixedMul(wave1, wave2);
      
      // Convert to 11-bit HDR color
      float normalizedWave = fixedToFloat(combined) * 0.5f + 0.5f;
      uint16_t intensity = normalizedWave * 2047; // 11-bit range
      
      // Get palette color and extend to HDR
      uint8_t paletteIndex = (timeOffset >> 6) + (i * 8);
      CRGB baseColor = ColorFromPalette(currentPalette, paletteIndex);
      
      // Expand 8-bit to 11-bit with HDR boost
      hdrBuffer[i].r = (baseColor.r << 3) + (intensity >> 6);
      hdrBuffer[i].g = (baseColor.g << 3) + (intensity >> 7);
      hdrBuffer[i].b = (baseColor.b << 3) + (intensity >> 8);
      hdrBuffer[i].brightness = 255;
      
      // Clamp to 11-bit range
      hdrBuffer[i].r = min(hdrBuffer[i].r, (uint16_t)2047);
      hdrBuffer[i].g = min(hdrBuffer[i].g, (uint16_t)2047);
      hdrBuffer[i].b = min(hdrBuffer[i].b, (uint16_t)2047);
    }
    
    // Convert HDR buffer to 8-bit with temporal dithering
    convertHDRToDisplay();
  }
  
  // Convert 11-bit HDR to 8-bit with temporal dithering
  void convertHDRToDisplay() {
    static uint8_t ditherFrame = 0;
    ditherFrame++;
    
    for (uint16_t i = 0; i < TOTAL_LEDS; i++) {
      // Temporal dithering for 11-bit simulation
      uint8_t dither = (ditherFrame + i) & 7; // 8-frame cycle
      
      // Convert 11-bit to 8-bit with dithering
      uint16_t r11 = hdrBuffer[i].r + dither;
      uint16_t g11 = hdrBuffer[i].g + dither;
      uint16_t b11 = hdrBuffer[i].b + dither;
      
      leds[i].r = r11 >> 3; // 11-bit to 8-bit
      leds[i].g = g11 >> 3;
      leds[i].b = b11 >> 3;
    }
  }
  
  // Super-sampling effect for ultra-smooth gradients
  void displaySupersampledEffect() {
    static float timePhase = 0;
    timePhase += paletteSpeed * 0.01f;
    
    // Clear supersampled buffer
    memset(supersampleBuffer, 0, sizeof(supersampleBuffer));
    
    // Generate at super-sampled resolution
    for (uint16_t i = 0; i < SUPERSAMPLED_LEDS; i++) {
      float position = (float)i / SUPERSAMPLED_LEDS;
      float wave = sin(position * 4.0f * PI + timePhase) * 0.5f + 0.5f;
      
      uint8_t paletteIndex = (position * 255) + (timePhase * 20);
      CRGB color = ColorFromPalette(currentPalette, paletteIndex);
      
      color.fadeToBlackBy(255 - (wave * 255));
      supersampleBuffer[i] = color;
    }
    
    // Downsample with anti-aliasing
    for (uint16_t i = 0; i < TOTAL_LEDS; i++) {
      uint32_t r = 0, g = 0, b = 0;
      
      // Average SUPERSAMPLE_FACTOR pixels
      for (uint8_t s = 0; s < SUPERSAMPLE_FACTOR; s++) {
        uint16_t srcIndex = (i * SUPERSAMPLE_FACTOR) + s;
        if (srcIndex < SUPERSAMPLED_LEDS) {
          r += supersampleBuffer[srcIndex].r;
          g += supersampleBuffer[srcIndex].g;
          b += supersampleBuffer[srcIndex].b;
        }
      }
      
      leds[i] = CRGB(r / SUPERSAMPLE_FACTOR, g / SUPERSAMPLE_FACTOR, b / SUPERSAMPLE_FACTOR);
    }
    
    // Apply additional blur for ultimate smoothness
    applyBlurEffect();
  }
  
  // Advanced blur effect for light diffusion
  void applyBlurEffect() {
    CRGB blurBuffer[TOTAL_LEDS];
    memcpy(blurBuffer, leds, sizeof(leds));
    
    for (uint16_t i = 0; i < TOTAL_LEDS; i++) {
      float r = 0, g = 0, b = 0;
      float totalWeight = 0;
      
      // Apply Gaussian blur kernel
      for (int8_t offset = -2; offset <= 2; offset++) {
        int16_t srcIndex = i + offset;
        
        // Handle edges with wrapping for crystal topology
        if (srcIndex < 0) srcIndex += TOTAL_LEDS;
        if (srcIndex >= TOTAL_LEDS) srcIndex -= TOTAL_LEDS;
        
        float weight = blurKernel[offset + 2] * diffusionMatrix[i];
        
        r += blurBuffer[srcIndex].r * weight;
        g += blurBuffer[srcIndex].g * weight;
        b += blurBuffer[srcIndex].b * weight;
        totalWeight += weight;
      }
      
      if (totalWeight > 0) {
        leds[i] = CRGB(r / totalWeight, g / totalWeight, b / totalWeight);
      }
    }
  }
  
  // Time-based alpha transition effect
  void displayTimeAlphaEffect() {
    if (!timeAlpha.active) {
      startTimeAlphaTransition(2000.0f, easeInOutSine); // 2 second transition
    }
    
    float alpha = getTimeAlpha();
    
    // Create two different effects and blend them
    CRGB effect1[TOTAL_LEDS];
    CRGB effect2[TOTAL_LEDS];
    
    // Effect 1: Rotating gradient
    for (uint16_t i = 0; i < TOTAL_LEDS; i++) {
      uint8_t hue = angles[i] + (millis() / 20);
      effect1[i] = CHSV(hue, 255, 200);
    }
    
    // Effect 2: Pulsing radial
    for (uint16_t i = 0; i < TOTAL_LEDS; i++) {
      uint8_t brightness = sin8(radii[i] + (millis() / 10));
      uint8_t paletteIndex = radii[i] + (millis() / 50);
      effect2[i] = ColorFromPalette(currentPalette, paletteIndex, brightness);
    }
    
    // Blend effects based on time alpha
    for (uint16_t i = 0; i < TOTAL_LEDS; i++) {
      leds[i] = blend(effect1[i], effect2[i], alpha * 255);
    }
  }
  
  // Start time-based transition
  void startTimeAlphaTransition(float duration, float (*easingFunc)(float)) {
    timeAlpha.startTime = millis();
    timeAlpha.duration = duration;
    timeAlpha.easingFunction = easingFunc;
    timeAlpha.active = true;
  }
  
  // Get current time alpha value (0.0 to 1.0)
  float getTimeAlpha() {
    if (!timeAlpha.active) return 1.0f;
    
    float elapsed = millis() - timeAlpha.startTime;
    if (elapsed >= timeAlpha.duration) {
      timeAlpha.active = false;
      return 1.0f;
    }
    
    float t = elapsed / timeAlpha.duration;
    return timeAlpha.easingFunction(t);
  }
  
  // Performance-optimized particle system
  void displayOptimizedParticles() {
    static const uint8_t MAX_PARTICLES = 20;
    struct Particle {
      fixed16_t x, y, vx, vy;
      uint8_t life, color;
      bool active;
    };
    
    static Particle particles[MAX_PARTICLES];
    static bool initialized = false;
    
    if (!initialized) {
      for (uint8_t i = 0; i < MAX_PARTICLES; i++) {
        particles[i].active = false;
      }
      initialized = true;
    }
    
    // Spawn new particles
    static uint32_t lastSpawn = 0;
    if (millis() - lastSpawn > 100) {
      for (uint8_t i = 0; i < MAX_PARTICLES; i++) {
        if (!particles[i].active) {
          particles[i].x = floatToFixed(random(TOTAL_LEDS));
          particles[i].y = floatToFixed(0);
          particles[i].vx = floatToFixed((random(200) - 100) * 0.01f);
          particles[i].vy = floatToFixed(random(50) * 0.01f + 0.5f);
          particles[i].life = 255;
          particles[i].color = random(255);
          particles[i].active = true;
          break;
        }
      }
      lastSpawn = millis();
    }
    
    // Apply fade
    fadeToBlackBy(leds, TOTAL_LEDS, fadeAmount);
    
    // Update and render particles
    for (uint8_t i = 0; i < MAX_PARTICLES; i++) {
      if (!particles[i].active) continue;
      
      Particle& p = particles[i];
      
      // Update position with fixed-point math
      p.x += p.vx;
      p.y += p.vy;
      
      // Update life
      p.life -= 3;
      if (p.life == 0) {
        p.active = false;
        continue;
      }
      
      // Render particle
      int16_t pixelX = fixedToFloat(p.x);
      if (pixelX >= 0 && pixelX < TOTAL_LEDS) {
        CRGB color = ColorFromPalette(currentPalette, p.color, p.life);
        leds[pixelX] += color;
      }
    }
  }
};

// Global advanced effects instance
extern AdvancedEffects advancedFX;

#endif // ADVANCED_EFFECTS_H