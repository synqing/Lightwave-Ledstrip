#ifndef CONFIG_H
#define CONFIG_H

// --- Debugging Flag (now less verbose) ---
#define ENABLE_EVENT_LOGGING true

// Light Crystals hardware configuration
#define NUM_STRIPS 1
#define LEDS_PER_STRIP 81
#define TOTAL_LEDS (NUM_STRIPS * LEDS_PER_STRIP)

// LED data pin
#define LED_PIN_1 6
// #define LED_PIN_2 17  // Not used in Light Crystals

// Onboard components
#define BUTTON_PIN 0
#define POWER_PIN 5
// #define STATUS_LED_PIN 35  // Not available on Light Crystals

// I2C Pins - Not used in Light Crystals (no M5Rotate8)
// #define I2C_SDA_PIN 2
// #define I2C_SCL_PIN 1

// Default parameters
#define DEFAULT_BRIGHTNESS 96

// Audio input pins (for future use)
#define I2S_SCK 3
#define I2S_WS 2
#define I2S_DIN 4

// Original matrix configuration (commented out)
// #define NUM_LEDS 64
// #define DATA_PIN 14
// #define BUT 0
// #define POWER_PIN 1
// #define MATRIX_WIDTH 8
// #define MATRIX_HEIGHT 8

#endif