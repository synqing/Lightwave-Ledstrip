#ifndef CONTROLS_H
#define CONTROLS_H

#include <FastLED.h>
#include <M5Unified.h>
#include "Config.h"
#include "Palettes.h"

extern uint8_t currentPaletteIndex;
extern CRGBPalette16 currentPalette;
extern uint8_t brightnessVal;
extern uint8_t fadeAmount;
extern uint16_t fps;
extern uint8_t paletteSpeed;
extern uint8_t visual_mode;

void do_buttons() {
  static unsigned long lastPress = 0;
  const uint16_t debounceDelay = 500;

  M5.update();
  
  if (M5.BtnA.wasPressed()) {
    unsigned long now = millis();
    if (now - lastPress >= debounceDelay) {
      lastPress = now;
      currentPaletteIndex = (currentPaletteIndex + 1) % 33;
      currentPalette = CRGBPalette16(gGradientPalettes[currentPaletteIndex]);
      Serial.print("Button Pressed, Palette: ");
      Serial.println(paletteNames[currentPaletteIndex]);
    }
  }
}

#endif