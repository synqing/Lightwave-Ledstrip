#ifndef ESPASYNCWEBSERVER_FIX_H
#define ESPASYNCWEBSERVER_FIX_H

// Fix for ESP32 Arduino Core 3.x compatibility
#if ESP_ARDUINO_VERSION >= ESP_ARDUINO_VERSION_VAL(3, 0, 0)
  #define mbedtls_md5_starts_ret mbedtls_md5_starts
  #define mbedtls_md5_update_ret mbedtls_md5_update
  #define mbedtls_md5_finish_ret mbedtls_md5_finish
#endif

#endif