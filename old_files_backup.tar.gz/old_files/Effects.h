#ifndef EFFECTS_H
#define EFFECTS_H

#include <FastLED.h>
#include "Config.h"
#include "StripMap.h"

// Original matrix implementation (commented out)
/*
extern CRGB leds[NUM_LEDS];
extern CRGB* leds2;
extern uint8_t noise[MATRIX_WIDTH][MATRIX_HEIGHT];
extern uint32_t xNoise, yNoise, zNoise;
extern uint32_t scale_x, scale_y;
extern uint8_t noisesmoothing;
extern uint8_t fibonacciToPhysical[NUM_LEDS];
extern uint8_t currentPaletteIndex;
extern CRGBPalette16 currentPalette;
extern uint8_t fadeAmount;

inline uint16_t XY(uint8_t x, uint8_t y) { return y * MATRIX_WIDTH + x; }

inline void DimAll(byte value) {
  for (int i = 0; i < NUM_LEDS; i++) leds[i].nscale8(value);
}

inline void FillNoise() {
  for (uint8_t i = 0; i < MATRIX_WIDTH; i++) {
    uint32_t ioffset = scale_x * (i - (MATRIX_WIDTH / 2));
    for (uint8_t j = 0; j < MATRIX_HEIGHT; j++) {
      uint32_t joffset = scale_y * (j - (MATRIX_HEIGHT / 2));
      byte data = inoise8(xNoise + ioffset, yNoise + joffset, zNoise);
      uint8_t olddata = noise[i][j];
      uint8_t newdata = scale8(olddata, noisesmoothing) + scale8(data, 256 - noisesmoothing);
      noise[i][j] = newdata;
    }
  }
}

inline void MoveX(byte delta) {
  if (!leds2) return;
  for (int y = 0; y < MATRIX_HEIGHT; y++) {
    for (int x = 0; x < MATRIX_WIDTH - delta; x++) {
      leds2[XY(x, y)] = leds[XY(x + delta, y)];
    }
    for (int x = MATRIX_WIDTH - delta; x < MATRIX_WIDTH; x++) {
      leds2[XY(x, y)] = leds[XY(x + delta - MATRIX_WIDTH, y)];
    }
  }
  for (uint8_t y = 0; y < MATRIX_HEIGHT; y++) {
    for (uint8_t x = 0; x < MATRIX_WIDTH; x++) {
      leds[XY(x, y)] = leds2[XY(x, y)];
    }
  }
}

inline void MoveFractionalNoiseX(byte amt = 8) {
  if (!leds2) return;
  for (int y = 0; y < MATRIX_HEIGHT; y++) {
    uint16_t amount = noise[y][0] * amt; // Adjusted to noise[y][0]
    byte delta = (MATRIX_WIDTH - 1) - (amount / 256);
    byte fractions = amount - (((MATRIX_WIDTH - 1) - delta) * 256);
    for (int x = 0; x < MATRIX_WIDTH - delta; x++) {
      leds2[XY(x, y)] = leds[XY(x + delta, y)];
    }
    for (int x = MATRIX_WIDTH - delta; x < MATRIX_WIDTH; x++) {
      leds2[XY(x, y)] = leds[XY(x + delta - MATRIX_WIDTH, y)];
    }
  }
  CRGB PixelA, PixelB;
  for (uint8_t y = 0; y < MATRIX_HEIGHT; y++) {
    uint16_t amount = noise[y][0] * amt; // Adjusted to noise[y][0]
    byte delta = (MATRIX_WIDTH - 1) - (amount / 256);
    byte fractions = amount - (((MATRIX_WIDTH - 1) - delta) * 256);
    for (uint8_t x = 1; x < MATRIX_WIDTH; x++) {
      PixelA = leds2[XY(x, y)]; PixelB = leds2[XY(x - 1, y)];
      PixelA %= 255 - fractions; PixelB %= fractions;
      leds[XY(x, y)] = PixelA + PixelB;
    }
    PixelA = leds2[XY(0, y)]; PixelB = leds2[XY(MATRIX_WIDTH - 1, y)];
    PixelA %= 255 - fractions; PixelB %= fractions;
    leds[XY(0, y)] = PixelA + PixelB;
  }
}

inline void PaletteSmear() {
  DimAll(170);
  for (uint8_t y = 0; y < MATRIX_HEIGHT; y++) {
    for (uint8_t x = 0; x < MATRIX_WIDTH; x++) {
      leds[XY(x, y)] += ColorFromPalette(currentPalette, x * 8, y * 8 + 7, LINEARBLEND);
    }
  }
  xNoise += 1000; yNoise += 1000;
  scale_x = 4000; scale_y = 4000;
  FillNoise();
  MoveX(8);
  MoveFractionalNoiseX();
}
*/

// New strip-based implementation for AtomS3U
extern CRGB leds[TOTAL_LEDS];
extern CRGB leds2[TOTAL_LEDS];
extern uint8_t noise[NUM_STRIPS][LEDS_PER_STRIP];
extern uint32_t xNoise[NUM_STRIPS], yNoise[NUM_STRIPS], zNoise[NUM_STRIPS];
extern uint32_t scale_x[NUM_STRIPS], scale_y[NUM_STRIPS];
extern uint8_t noisesmoothing;
extern uint8_t stripPositions[TOTAL_LEDS];
extern uint8_t stripNumbers[TOTAL_LEDS];
extern uint8_t angles[TOTAL_LEDS];
extern uint8_t radii[TOTAL_LEDS];
extern uint8_t currentPaletteIndex;
extern CRGBPalette16 currentPalette;
extern uint8_t fadeAmount;

// Dim all LEDs
inline void DimAll(byte value) {
  for (int i = 0; i < TOTAL_LEDS; i++) leds[i].nscale8(value);
}

// Fill noise array for a specific strip
inline void FillNoise(byte strip) {
  for (uint16_t i = 0; i < LEDS_PER_STRIP; i++) {
    uint32_t ioffset = scale_x[strip] * (i - (LEDS_PER_STRIP / 2));
    byte data = inoise8(xNoise[strip] + ioffset, yNoise[strip], zNoise[strip]);
    uint8_t olddata = noise[strip][i];
    uint8_t newdata = scale8(olddata, noisesmoothing) + scale8(data, 256 - noisesmoothing);
    noise[strip][i] = newdata;
  }
}

// Move pixels along a specific strip
inline void MoveStrip(uint8_t strip, byte delta) {
  for (int i = 0; i < LEDS_PER_STRIP - delta; i++) {
    uint16_t src = getPixelIndex(strip, i + delta);
    uint16_t dst = getPixelIndex(strip, i);
    leds2[dst] = leds[src];
  }
  
  for (int i = LEDS_PER_STRIP - delta; i < LEDS_PER_STRIP; i++) {
    uint16_t src = getPixelIndex(strip, i + delta - LEDS_PER_STRIP);
    uint16_t dst = getPixelIndex(strip, i);
    leds2[dst] = leds[src];
  }
  
  for (int i = 0; i < LEDS_PER_STRIP; i++) {
    uint16_t idx = getPixelIndex(strip, i);
    leds[idx] = leds2[idx];
  }
}

// Apply fractional noise-based movement to a strip
inline void MoveFractionalNoiseStrip(uint8_t strip, byte amt = 8) {
  uint16_t amount = noise[strip][0] * amt;
  byte delta = (LEDS_PER_STRIP - 1) - (amount / 256);
  
  for (int i = 0; i < LEDS_PER_STRIP - delta; i++) {
    uint16_t src = getPixelIndex(strip, i + delta);
    uint16_t dst = getPixelIndex(strip, i);
    leds2[dst] = leds[src];
  }
  
  for (int i = LEDS_PER_STRIP - delta; i < LEDS_PER_STRIP; i++) {
    uint16_t src = getPixelIndex(strip, i + delta - LEDS_PER_STRIP);
    uint16_t dst = getPixelIndex(strip, i);
    leds2[dst] = leds[src];
  }
  
  byte fractions = amount - (((LEDS_PER_STRIP - 1) - delta) * 256);
  CRGB PixelA, PixelB;
  
  for (uint16_t i = 1; i < LEDS_PER_STRIP; i++) {
    uint16_t idxA = getPixelIndex(strip, i);
    uint16_t idxB = getPixelIndex(strip, i - 1);
    PixelA = leds2[idxA];
    PixelB = leds2[idxB];
    PixelA %= 255 - fractions;
    PixelB %= fractions;
    leds[idxA] = PixelA + PixelB;
  }
  
  uint16_t idx0 = getPixelIndex(strip, 0);
  uint16_t idxLast = getPixelIndex(strip, LEDS_PER_STRIP - 1);
  PixelA = leds2[idx0];
  PixelB = leds2[idxLast];
  PixelA %= 255 - fractions;
  PixelB %= fractions;
  leds[idx0] = PixelA + PixelB;
}

// Apply palette smear effect to both strips
inline void PaletteSmear() {
  DimAll(170);
  
  // Apply palette colors across all strips
  for (uint8_t strip = 0; strip < NUM_STRIPS; strip++) {
    for (uint16_t i = 0; i < LEDS_PER_STRIP; i++) {
      uint16_t idx = getPixelIndex(strip, i);
      uint8_t colorIndex = map(i, 0, LEDS_PER_STRIP-1, 0, 255);
      leds[idx] += ColorFromPalette(currentPalette, colorIndex, 255, LINEARBLEND);
    }
  }
  
  // Update noise and apply movement to each strip
  for (uint8_t strip = 0; strip < NUM_STRIPS; strip++) {
    xNoise[strip] += 1000;
    scale_x[strip] = 4000;
    FillNoise(strip);
    
    // Apply movement effects
    uint8_t moveDelta = beatsin8(10, 1, 8);
    MoveStrip(strip, moveDelta);
    MoveFractionalNoiseStrip(strip);
  }
}

#endif
