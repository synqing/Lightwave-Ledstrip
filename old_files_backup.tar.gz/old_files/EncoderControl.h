#ifndef ENCODER_CONTROL_H
#define ENCODER_CONTROL_H

#include <M5Unified.h>
#include "m5rotate8.h"
#include <Wire.h>
#include "Config.h"

// Encoder library instance
M5ROTATE8 rotate8;

// Global variables for encoder state
bool g_rotate8_available = false;
bool g_encoders_enabled = true;
uint32_t g_next_recovery_attempt = 0;
uint32_t g_last_encoder_activity_time = 0;
uint8_t g_last_active_encoder = 0;

// For encoder 3 mode control
bool encoder3_in_contrast_mode = false;
uint32_t encoder3_button_hold_start = 0;

// Default parameter values for reset functionality (renamed to avoid conflicts)
#define ENCODER_DEFAULT_BRIGHTNESS DEFAULT_BRIGHTNESS
#define ENCODER_DEFAULT_PALETTE_SPEED 10
#define ENCODER_DEFAULT_FADE_AMOUNT 20
#define ENCODER_DEFAULT_FPS 120  // Default FPS is still 120, but will allow up to 1000
#define ENCODER_DEFAULT_PALETTE_INDEX 0
#define ENCODER_DEFAULT_SECOND_PALETTE_INDEX 0  // Default for second strip palette
#define ENCODER_DEFAULT_VISUAL_MODE 1

// Parameter definitions for mapping encoders to effect parameters
extern uint8_t brightnessVal;
extern uint8_t fadeAmount;
extern uint16_t fps;
extern uint8_t paletteSpeed;
extern uint8_t currentPaletteIndex;
extern uint8_t secondStripPaletteIndex;  // Add the second strip palette index
extern uint8_t visual_mode;
extern CRGBPalette16 currentPalette;
extern CRGBPalette16 targetPalette;
extern CRGBPalette16 secondStripPalette;  // Add the second strip palette
extern CRGBPalette16 secondStripTarget;   // Add the second strip target
extern const TProgmemRGBGradientPaletteRef gGradientPalettes[];

// For tracking changes
bool settings_updated = false;

// Add this function before attempt_rotate8_init
void force_recover_i2c() {
  if (ENABLE_EVENT_LOGGING) Serial.println("[DBG] Attempting forceful I2C bus recovery...");
  // Correct pins: SCL=G2, SDA=G1
  pinMode(I2C_SCL_PIN, OUTPUT);         // Use define for SCL pin
  pinMode(I2C_SDA_PIN, INPUT_PULLUP); // Use define for SDA pin

  // Try to clock out any stuck bits by toggling SCL (I2C_SCL_PIN)
  // while monitoring SDA (I2C_SDA_PIN)
  for (int i = 0; i < 16; i++) {
    digitalWrite(I2C_SCL_PIN, LOW);
    delayMicroseconds(5);
    digitalWrite(I2C_SCL_PIN, HIGH);
    delayMicroseconds(5);
    if (digitalRead(I2C_SDA_PIN) == HIGH) { // Check if SDA released
        if (ENABLE_EVENT_LOGGING) Serial.println("[DBG] SDA line released during clock toggle.");
        break; // SDA is high, bus might be free
    }
  }

  // Attempt to generate a STOP condition manually: SCL high, SDA low -> high
  digitalWrite(I2C_SCL_PIN, HIGH);
  digitalWrite(I2C_SDA_PIN, LOW);
  delayMicroseconds(5);
  digitalWrite(I2C_SDA_PIN, HIGH);
  delayMicroseconds(5);

  // Return pins to INPUT state before Wire.begin takes control
  pinMode(I2C_SCL_PIN, INPUT);
  pinMode(I2C_SDA_PIN, INPUT);
  if (ENABLE_EVENT_LOGGING) Serial.println("[DBG] Forceful I2C recovery attempt finished.");
}

// Function to attempt encoder initialization with multiple retries
void attempt_rotate8_init(bool verbose) {
  bool rotate8_initialized = false;
  const int max_attempts = verbose ? 3 : 1; // More attempts during setup, only one during runtime
  
  for (int attempt = 0; attempt < max_attempts && !rotate8_initialized; attempt++) {
    if (verbose) {
      Serial.print("Attempting to initialize M5Rotate8 (Attempt ");
      Serial.print(attempt + 1);
      Serial.print("/");
      Serial.print(max_attempts);
      Serial.println(")...");
    }
    
    // Reset I2C bus before attempting initialization
    Wire.end();
    delay(50);
    force_recover_i2c(); // Call the forceful recovery function
    delay(50);
    Wire.begin(I2C_SDA_PIN, I2C_SCL_PIN); // Use defines for SDA and SCL pins
    delay(50);
    
    // Attempt initialization
    rotate8_initialized = rotate8.begin();
    
    if (rotate8_initialized) {
      g_rotate8_available = true;
      if (verbose) {
        Serial.println("M5Rotate8 Initialized Successfully.");
        uint8_t version = rotate8.getVersion();
        Serial.print("Firmware Version: ");
        Serial.println(version);
      } else {
        Serial.println("M5Rotate8 recovered successfully!");
      }
      
      // Initialize all encoder LEDs to off state
      for (uint8_t i = 0; i < 9; i++) {
        rotate8.writeRGB(i, 0, 0, 0);
      }
    } else {
      g_rotate8_available = false;
      if (verbose) {
        Serial.println("M5Rotate8 Initialization FAILED. Retrying...");
      }
      delay(200); // Wait before trying again
    }
  }
  
  if (!rotate8_initialized) {
    if (verbose) {
      Serial.println("WARNING: M5Rotate8 failed to initialize after multiple attempts!");
      Serial.println("System will continue in fallback mode without encoders.");
      Serial.println("Encoders will be checked periodically for reconnection.");
    }
    
    // Schedule next recovery attempt
    g_next_recovery_attempt = millis() + 10000; // Try again in 10 seconds
  }
}

// Function to check encoders and update parameters
void check_encoders(uint32_t t_now) {
  // If encoders aren't available, exit immediately
  if (!g_rotate8_available) return;
  
  // Constants for encoder configuration
  const float sensitivity_divisor_float = 30.0; // Increased sensitivity (was 120.0)
  const int sensitivity_divisor_palette = 1;    // Increased sensitivity (was 4)
  
  // For handling encoder state and rate limiting
  static uint32_t last_encoder_check = 0;
  static bool encoder_button_last_state[8] = {false, false, false, false, false, false, false, false};
  static bool encoder_error_state = false;
  static uint32_t error_recovery_time = 0;
  static uint32_t encoder_error_count = 0;
  static int32_t last_encoder_values[8] = {0};
  static int32_t accumulated_values[8] = {0};
  
  // Improved debouncing variables - protect against cross-talk
  static uint32_t last_encoder_change_time[8] = {0};
  static uint8_t last_active_encoder_id = 255;
  static const uint32_t encoder_lockout_time = 50; // 50ms for better isolation between encoders
  
  // Button press debouncing and timing
  static uint32_t last_button_press[8] = {0};
  static const uint32_t button_debounce_time = 400; // 400ms debounce time
  static const uint32_t long_press_threshold = 800; // Time to hold for long press
  static uint32_t button_hold_start[8] = {0};
  
  // Track encoder activity for UI feedback
  bool activity_detected = false;
  
  // Rate limiting - only check encoders every 15ms
  if (t_now - last_encoder_check < 15) {
    return; // Exit early, don't process encoders too frequently
  }
  last_encoder_check = t_now;
  
  // Error recovery mechanism
  if (encoder_error_state) {
    if (t_now - error_recovery_time < 1000) {
      return; // Still in recovery mode, skip encoder processing
    }
    
    // Try to recover by reinitializing the encoder interface
    g_rotate8_available = false;
    attempt_rotate8_init(false);
    
    if (!g_rotate8_available) {
      // Still failing, wait longer
      error_recovery_time = t_now;
      return;
    }
    
    // Reset error state and continue
    encoder_error_state = false;
    encoder_error_count = 0;
    for (int i = 0; i < 8; i++) {
      accumulated_values[i] = 0;
      last_encoder_values[i] = 0;
    }
  }
  
  // Helper function to safely read encoder values with error handling and enhanced debouncing
  auto safeGetRelCounter = [&](uint8_t channel) -> int32_t {
    int32_t value = 0;
    bool read_successful = false; 

    // Enhanced cross-talk protection - strict encoder isolation
    // If another encoder was active recently, delay processing this one
    if (last_active_encoder_id != 255 && 
        last_active_encoder_id != channel && 
        (t_now - last_encoder_change_time[last_active_encoder_id] < encoder_lockout_time)) {
      return 0; // Skip this reading - too soon after another encoder was active
    }

    // Attempt to read the encoder, handling potential errors
    try {
      value = rotate8.getRelCounter(channel);
      read_successful = true;
    } 
    catch (...) {
      // Any exception during read indicates a problem with the encoders
      encoder_error_count++;
      value = 0;
      read_successful = false;
    }

    // If read was successful, perform robust sanity checks
    if (read_successful) {
      // Detect unreasonable values that might indicate problems - stricter constraints
      if (value > 40 || value < -40) {
        encoder_error_count++;
        value = 0; // Ignore suspiciously large values - reduced threshold for stability
      } else if (value != 0) {
        // Apply accumulation only for valid readings
        accumulated_values[channel] += value;
        
        // Cap accumulated values to prevent overflow
        if (accumulated_values[channel] > 100) accumulated_values[channel] = 100;
        if (accumulated_values[channel] < -100) accumulated_values[channel] = -100;
        
        // Update debouncing trackers
        last_encoder_change_time[channel] = t_now;
        last_active_encoder_id = channel;
        
        // Return the value and reset accumulator if used
        value = accumulated_values[channel];
        accumulated_values[channel] = 0; // Reset after use
        
        // Success, reset error counter
        encoder_error_count = 0;
      }
    } else {
      // Treat read failure as an error
      encoder_error_count++;
      value = 0;
    }

    // Enter error recovery mode if needed
    if (encoder_error_count > 5) { // Reduced threshold to catch failures faster
      encoder_error_state = true;
      error_recovery_time = t_now;
      g_rotate8_available = false; // Mark encoder as unavailable
      g_next_recovery_attempt = t_now + 5000; // Schedule recovery attempt in 5 seconds
      Serial.println("WARNING: Encoder communication errors detected. Entering recovery mode.");
      return 0;
    }
    
    return value;
  };
  
  // Helper function to safely read button states
  auto safeGetButtonState = [&](uint8_t channel) -> bool {
    bool button_state = false;
    try {
      button_state = rotate8.getKeyPressed(channel);
    } catch (...) {
      encoder_error_count++;
      if (encoder_error_count > 5) {
        encoder_error_state = true;
        error_recovery_time = t_now;
        g_rotate8_available = false;
        g_next_recovery_attempt = t_now + 5000;
        Serial.println("WARNING: Button read errors detected. Entering recovery mode.");
      }
      return false;
    }
    return button_state;
  };
  
  // Process each encoder with proper error handling
  // --- Encoder 0: BRIGHTNESS ---
  int32_t brightness_rel = safeGetRelCounter(0);
  if (brightness_rel != 0) {
    float change = (float)brightness_rel / sensitivity_divisor_float;
    float new_value = brightnessVal + change * 255.0; // Scale to 0-255 range
    
    // Implement hard stops with direction awareness
    if ((new_value <= 255.0 && brightness_rel > 0) || (new_value >= 0.0 && brightness_rel < 0)) {
      activity_detected = true;
      g_last_active_encoder = 0;
      
      // Apply change with bounds protection
      brightnessVal = constrain(new_value, 0, 255);
      FastLED.setBrightness(brightnessVal);
      settings_updated = true;
      
      if (brightness_rel != 0) {
        Serial.print("Brightness: ");
        Serial.println(brightnessVal);
      }
    }
  }

  // Check button press for Encoder 0 (brightness reset)
  bool button0_state = safeGetButtonState(0);
  if (t_now - last_button_press[0] > button_debounce_time) {
    // Detect button press start
    if (button0_state && !encoder_button_last_state[0]) {
      button_hold_start[0] = t_now;
    }
    
    // Detect button release
    if (!button0_state && encoder_button_last_state[0]) {
      activity_detected = true;
      g_last_active_encoder = 0;
      
      // Reset brightness to default
      brightnessVal = ENCODER_DEFAULT_BRIGHTNESS;
      FastLED.setBrightness(brightnessVal);
      settings_updated = true;
      last_button_press[0] = t_now;
      
      Serial.print("Reset Brightness to default: ");
      Serial.println(brightnessVal);
    }
  }
  encoder_button_last_state[0] = button0_state;

  // --- Encoder 1: PALETTE SPEED ---
  int32_t palette_speed_rel = safeGetRelCounter(1);
  if (palette_speed_rel != 0) {
    float change = (float)palette_speed_rel / sensitivity_divisor_float;
    float new_value = paletteSpeed + change * 50.0; // Scale to 0-50 range
    
    // Implement hard stops with direction awareness
    if ((new_value <= 50.0 && palette_speed_rel > 0) || (new_value >= 1.0 && palette_speed_rel < 0)) {
      activity_detected = true;
      g_last_active_encoder = 1;
      
      // Apply change with bounds protection
      paletteSpeed = constrain(new_value, 1, 50);
      settings_updated = true;
      
      if (palette_speed_rel != 0) {
        Serial.print("Palette Speed: ");
        Serial.println(paletteSpeed);
      }
    }
  }

  // Check button press for Encoder 1 (palette speed reset)
  bool button1_state = safeGetButtonState(1);
  if (t_now - last_button_press[1] > button_debounce_time) {
    // Detect button press start
    if (button1_state && !encoder_button_last_state[1]) {
      button_hold_start[1] = t_now;
    }
    
    // Detect button release
    if (!button1_state && encoder_button_last_state[1]) {
      activity_detected = true;
      g_last_active_encoder = 1;
      
      // Reset palette speed to default
      paletteSpeed = ENCODER_DEFAULT_PALETTE_SPEED;
      settings_updated = true;
      last_button_press[1] = t_now;
      
      Serial.print("Reset Palette Speed to default: ");
      Serial.println(paletteSpeed);
    }
  }
  encoder_button_last_state[1] = button1_state;

  // --- Encoder 2: FADE AMOUNT ---
  int32_t fade_rel = safeGetRelCounter(2);
  if (fade_rel != 0) {
    float change = (float)fade_rel / sensitivity_divisor_float;
    float new_value = fadeAmount + change * 255.0; // Scale to 0-255 range
    
    // Implement hard stops with direction awareness
    if ((new_value <= 255.0 && fade_rel > 0) || (new_value >= 0.0 && fade_rel < 0)) {
      activity_detected = true;
      g_last_active_encoder = 2;
      
      // Apply change with bounds protection
      fadeAmount = constrain(new_value, 0, 255);
      settings_updated = true;
      
      if (fade_rel != 0) {
        Serial.print("Fade Amount: ");
        Serial.println(fadeAmount);
      }
    }
  }

  // Check button press for Encoder 2 (fade amount reset)
  bool button2_state = safeGetButtonState(2);
  if (t_now - last_button_press[2] > button_debounce_time) {
    // Detect button press start
    if (button2_state && !encoder_button_last_state[2]) {
      button_hold_start[2] = t_now;
    }
    
    // Detect button release
    if (!button2_state && encoder_button_last_state[2]) {
      activity_detected = true;
      g_last_active_encoder = 2;
      
      // Reset fade amount to default
      fadeAmount = ENCODER_DEFAULT_FADE_AMOUNT;
      settings_updated = true;
      last_button_press[2] = t_now;
      
      Serial.print("Reset Fade Amount to default: ");
      Serial.println(fadeAmount);
    }
  }
  encoder_button_last_state[2] = button2_state;

  // --- Encoder 3: VISUAL MODE / FPS (keep existing functionality but refactor) ---
  bool encoder3_button_state = safeGetButtonState(3);
  
  if (t_now - last_button_press[3] > button_debounce_time) {
    // Detect button press start for long-press detection
    if (encoder3_button_state && !encoder_button_last_state[3]) {
      encoder3_button_hold_start = t_now;
    }
    
    // Detect button release after hold
    if (!encoder3_button_state && encoder_button_last_state[3]) {
      // Check if it was a long press (for switching modes)
      if (t_now - encoder3_button_hold_start >= long_press_threshold) {
        // Toggle contrast mode on long press
        encoder3_in_contrast_mode = !encoder3_in_contrast_mode;
        activity_detected = true;
        g_last_active_encoder = 3;
        last_button_press[3] = t_now;
        
        Serial.print("Contrast Mode: ");
        Serial.println(encoder3_in_contrast_mode ? "ON" : "OFF");
      } 
      // Short press behavior depends on current mode
      else {
        activity_detected = true;
        g_last_active_encoder = 3;
        
        if (encoder3_in_contrast_mode) {
          // In contrast mode, reset fps to default
          fps = ENCODER_DEFAULT_FPS;
          settings_updated = true;
          Serial.print("Reset FPS to default: ");
          Serial.println(fps);
        } else {
          // In normal mode, reset to default visual mode or cycle modes
          visual_mode = ENCODER_DEFAULT_VISUAL_MODE; // Reset to default instead of cycling
          // Ensure we never go out of bounds
          visual_mode = constrain(visual_mode, 0, 2);
          settings_updated = true;
          Serial.print("Reset Visual Mode to default: ");
          Serial.println(visual_mode);
        }
        
        last_button_press[3] = t_now;
      }
    }
  }
  encoder_button_last_state[3] = encoder3_button_state;
  
  // Handle encoder rotation for FPS adjustment when in contrast mode
  if (encoder3_in_contrast_mode) {
    int32_t fps_rel = safeGetRelCounter(3);
    if (fps_rel != 0) {
      // More responsive fps control with higher max range
      float fps_change = (float)fps_rel / 25.0; 
      float new_value = fps + fps_change * 1000.0; // Scale to 1-1000 range (was 120)
      
      // Implement hard stops with direction awareness
      if ((new_value <= 1000.0 && fps_rel > 0) || (new_value >= 1.0 && fps_rel < 0)) {
        activity_detected = true;
        g_last_active_encoder = 3;
        
        // Apply change with bounds protection
        fps = constrain(new_value, 1, 1000); // Increased upper limit to 1000
        settings_updated = true;
        
        Serial.print("FPS: ");
        Serial.println(fps);
      }
    }
  }

  // --- Encoder 4: PALETTE SELECTION ---
  int32_t palette_rel = safeGetRelCounter(4);
  if (palette_rel != 0) {
    int32_t palette_change = palette_rel / sensitivity_divisor_palette;
    
    if (palette_change != 0) {
      // Handle palette selection with strict bounds checking
      int new_palette = currentPaletteIndex + palette_change;
      
      // Enforce hard bounds with wrap-around behavior
      if (new_palette < 0) {
        new_palette = 32; // Wrap to last palette
      } else if (new_palette > 32) {
        new_palette = 0; // Wrap to first palette
      }
      
      // Extra validation to ensure we never go out of bounds
      new_palette = constrain(new_palette, 0, 32);
      
      activity_detected = true;
      g_last_active_encoder = 4;
      
      // Update the palette
      currentPaletteIndex = new_palette;
      targetPalette = CRGBPalette16(gGradientPalettes[currentPaletteIndex]);
      settings_updated = true;
      
      Serial.print("Palette Index: ");
      Serial.println(currentPaletteIndex);
    }
  }

  // Check button press for Encoder 4 (palette reset)
  bool button4_state = safeGetButtonState(4);
  if (t_now - last_button_press[4] > button_debounce_time) {
    // Detect button press start
    if (button4_state && !encoder_button_last_state[4]) {
      button_hold_start[4] = t_now;
    }
    
    // Detect button release
    if (!button4_state && encoder_button_last_state[4]) {
      activity_detected = true;
      g_last_active_encoder = 4;
      
      // Reset palette to default
      currentPaletteIndex = ENCODER_DEFAULT_PALETTE_INDEX;
      targetPalette = CRGBPalette16(gGradientPalettes[currentPaletteIndex]);
      settings_updated = true;
      last_button_press[4] = t_now;
      
      Serial.print("Reset Palette to default: ");
      Serial.println(currentPaletteIndex);
    }
  }
  encoder_button_last_state[4] = button4_state;

  // --- Encoder 5: SECOND STRIP PALETTE SELECTION ---
  int32_t second_palette_rel = safeGetRelCounter(5);
  if (second_palette_rel != 0) {
    int32_t palette_change = second_palette_rel / sensitivity_divisor_palette;
    
    if (palette_change != 0) {
      // Handle palette selection with strict bounds checking
      int new_palette = secondStripPaletteIndex + palette_change;
      
      // Enforce hard bounds with wrap-around behavior
      if (new_palette < 0) {
        new_palette = 32; // Wrap to last palette
      } else if (new_palette > 32) {
        new_palette = 0; // Wrap to first palette
      }
      
      // Extra validation to ensure we never go out of bounds
      new_palette = constrain(new_palette, 0, 32);
      
      activity_detected = true;
      g_last_active_encoder = 5;
      
      // Update the second strip palette
      secondStripPaletteIndex = new_palette;
      secondStripTarget = CRGBPalette16(gGradientPalettes[secondStripPaletteIndex]);
      settings_updated = true;
      
      Serial.print("Second Strip Palette Index: ");
      Serial.println(secondStripPaletteIndex);
    }
  }
  
  // Check button press for Encoder 5 (second strip palette reset)
  bool button5_state = safeGetButtonState(5);
  if (t_now - last_button_press[5] > button_debounce_time) {
    // Detect button press start
    if (button5_state && !encoder_button_last_state[5]) {
      button_hold_start[5] = t_now;
    }
    
    // Detect button release
    if (!button5_state && encoder_button_last_state[5]) {
      activity_detected = true;
      g_last_active_encoder = 5;
      
      // Reset second strip palette to default
      secondStripPaletteIndex = ENCODER_DEFAULT_SECOND_PALETTE_INDEX;
      secondStripTarget = CRGBPalette16(gGradientPalettes[secondStripPaletteIndex]);
      settings_updated = true;
      last_button_press[5] = t_now;
      
      Serial.print("Reset Second Strip Palette to default: ");
      Serial.println(secondStripPaletteIndex);
    }
  }
  encoder_button_last_state[5] = button5_state;

  // --- Encoder 6: For Future Parameter ---
  int32_t enc6_rel = safeGetRelCounter(6);
  if (enc6_rel != 0) {
    activity_detected = true;
    g_last_active_encoder = 6;
    
    // Reserved for future parameter
    // Currently shows detection only
    if (enc6_rel != 0) {
      Serial.print("Encoder 6: ");
      Serial.println(enc6_rel);
    }
  }
  
  // --- Encoder 7: For Future Parameter ---
  int32_t enc7_rel = safeGetRelCounter(7);
  if (enc7_rel != 0) {
    activity_detected = true;
    g_last_active_encoder = 7;
    
    // Reserved for future parameter
    // Currently shows detection only
    if (enc7_rel != 0) {
      Serial.print("Encoder 7: ");
      Serial.println(enc7_rel);
    }
  }
  
  // Update global last activity time if any encoder was active
  if (activity_detected) {
    g_last_encoder_activity_time = t_now;
  }
}

// Function to update encoder LEDs
void update_encoder_leds() {
  // Skip if encoders are not available
  if (!g_rotate8_available) return;
  
  // Define fixed colors for each encoder LED (0-7)
  static const uint8_t active_colors[8][3] = {
    {64, 64, 64}, // 0: Brightness (White)
    {255, 64, 0}, // 1: Palette Speed (Orange)
    {128, 128, 0}, // 2: Fade Amount (Yellow)
    {0, 64, 0},   // 3: Visual Mode/FPS (Green)
    {0, 64, 128}, // 4: Palette Selection (Blue)
    {64, 0, 64},  // 5: Reserved (Purple)
    {64, 0, 0},   // 6: Reserved (Red)
    {0, 64, 0}    // 7: Reserved (Green)
  };
  
  // Add contrast mode indicator - pulsing green for encoder 3
  static uint8_t contrast_indicator = 0;
  static uint32_t last_pulse_time = 0;
  static bool pulse_direction = true;
  
  // Pulse the contrast indicator every 20ms when in contrast mode
  if (millis() - last_pulse_time > 20) {
    if (pulse_direction) {
      contrast_indicator += 5;
      if (contrast_indicator >= 80) pulse_direction = false;
    } else {
      contrast_indicator -= 5;
      if (contrast_indicator <= 10) pulse_direction = true;
    }
    last_pulse_time = millis();
  }
  
  // Inactive color - very dim blue
  static const uint8_t inactive_r = 0; 
  static const uint8_t inactive_g = 0;
  static const uint8_t inactive_b = 4; // Very dim
  
  // Find which encoder is currently active
  static uint32_t last_check_time = 0;
  static uint8_t current_active_encoder = 255;
  static uint8_t last_written_states[9] = {0}; // Track LED states - including LED 9
  
  // Only check activity and update LEDs every 100ms to reduce I2C traffic
  if (millis() - last_check_time > 100) {
    last_check_time = millis();
    
    // Simple timeout calculation - 2 second timeout
    if (millis() - g_last_encoder_activity_time < 2000) {
      current_active_encoder = g_last_active_encoder;
    } else {
      current_active_encoder = 255; // No active encoder
    }
    
    // Update LEDs only when needed, and only those that changed state
    for (uint8_t i = 0; i < 8; i++) {
      uint8_t new_state = (i == current_active_encoder) ? 1 : 0;
      
      // Special handling for encoder 3 when in contrast mode
      if (i == 3 && encoder3_in_contrast_mode) {
        // Use pulsing effect for contrast mode
        try {
          rotate8.writeRGB(i, 0, contrast_indicator, 0);
          last_written_states[i] = 2; // Special state for contrast mode
        } catch (...) {
          // If there's an error writing to LEDs, mark encoder as unavailable
          g_rotate8_available = false;
          g_next_recovery_attempt = millis() + 5000;
          Serial.println("WARNING: Encoder LED communication error. Entering recovery mode.");
          return; // Exit function to prevent further errors
        }
      }
      // Only update if the state has changed, to minimize I2C traffic
      else if (new_state != last_written_states[i]) {
        last_written_states[i] = new_state;
        
        try {
          if (new_state) {
            rotate8.writeRGB(i, active_colors[i][0], active_colors[i][1], active_colors[i][2]);
          } else {
            rotate8.writeRGB(i, inactive_r, inactive_g, inactive_b);
          }
        } catch (...) {
          // If there's an error writing to LEDs, mark encoder as unavailable
          g_rotate8_available = false;
          g_next_recovery_attempt = millis() + 5000;
          Serial.println("WARNING: Encoder LED communication error. Entering recovery mode.");
          return; // Exit function to prevent further errors
        }
      }
    }
    
    // Explicitly turn off LED 9 (which is unused) to prevent flashing
    if (last_written_states[8] != 0) {
      try {
        rotate8.writeRGB(8, 0, 0, 0); // Completely off
        last_written_states[8] = 0;
      } catch (...) {
        // If there's an error writing to LEDs, mark encoder as unavailable
        g_rotate8_available = false;
        g_next_recovery_attempt = millis() + 5000;
        Serial.println("WARNING: Encoder LED communication error. Entering recovery mode.");
      }
    }
  }
}

// Main function to call in loop to handle encoder operations
void handle_encoders() {
  uint32_t now = millis();
  
  // Attempt recovery of M5Rotate8 if it's not available and it's time to try again
  if (!g_rotate8_available && now > g_next_recovery_attempt) {
    attempt_rotate8_init(false); // false = non-verbose
  }
  
  // Check the M5Rotate8 encoder board if available
  if (g_encoders_enabled && g_rotate8_available) {
    // Use the improved encoder handling
    check_encoders(now);
    
    // Update encoder LEDs with improved function
    update_encoder_leds();
  }
}

#endif // ENCODER_CONTROL_H 