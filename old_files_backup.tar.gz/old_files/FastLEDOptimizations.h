#ifndef FASTLED_OPTIMIZATIONS_H
#define FASTLED_OPTIMIZATIONS_H

#include <FastLED.h>
#include "Config.h"

// FastLED 3.10.0 Advanced Optimizations
class FastLEDOptimizer {
private:
  // Power management
  uint32_t maxPowerInMilliWatts = 5000; // 5W default
  uint8_t targetBrightness = 255;
  
  // Temporal dithering state
  uint8_t ditherFrame = 0;
  bool temporalDitheringEnabled = true;
  
  // Gamma correction tables
  static const uint8_t PROGMEM gamma8[];
  static const uint16_t PROGMEM gamma16[];
  
public:
  
  // 1. POWER MANAGEMENT - Prevent brownouts and manage current draw
  void setPowerLimit(uint32_t milliWatts, uint8_t targetBright = 255) {
    maxPowerInMilliWatts = milliWatts;
    targetBrightness = targetBright;
    
    // FastLED's intelligent power management
    set_max_power_in_volts_and_milliamps(5, milliWatts / 5);
    
    Serial.print(F("[OPT] Power limit set to "));
    Serial.print(milliWatts);
    Serial.println(F(" mW"));
  }
  
  // Calculate actual power draw
  uint32_t calculatePowerDraw(CRGB* leds, uint16_t numLeds) {
    return calculate_unscaled_power_mW(leds, numLeds);
  }
  
  // Auto-adjust brightness to stay within power limits
  void autoBrightnessForPower(CRGB* leds, uint16_t numLeds) {
    uint32_t currentPower = calculatePowerDraw(leds, numLeds);
    
    if (currentPower > maxPowerInMilliWatts) {
      uint8_t scaledown = (maxPowerInMilliWatts * 256) / currentPower;
      uint8_t newBrightness = (targetBrightness * scaledown) / 256;
      
      FastLED.setBrightness(newBrightness);
      
      Serial.print(F("[PWR] Auto-dimmed to "));
      Serial.print(newBrightness);
      Serial.print(F(" ("));
      Serial.print(currentPower);
      Serial.println(F(" mW draw)"));
    }
  }
  
  // 2. COLOR CORRECTION & TEMPERATURE
  void applyAdvancedColorCorrection() {
    // Temperature correction for accurate whites
    FastLED.setTemperature(Tungsten40W); // Warm white
    
    // Per-strip color correction if needed
    FastLED.setCorrection(TypicalSMD5050);
    
    // Custom color correction matrix
    CRGB colorCorrection = CRGB(255, 200, 140); // Compensate for LED characteristics
    FastLED.setCorrection(colorCorrection);
  }
  
  // 3. TEMPORAL DITHERING - Simulate higher bit depth
  void enableTemporalDithering(bool enable = true) {
    temporalDitheringEnabled = enable;
    FastLED.setDither(enable ? BINARY_DITHER : DISABLE_DITHER);
    
    Serial.print(F("[OPT] Temporal dithering "));
    Serial.println(enable ? F("enabled") : F("disabled"));
  }
  
  // Apply temporal dithering manually for 12-bit color
  void apply12BitDithering(CRGB* leds, uint16_t numLeds) {
    if (!temporalDitheringEnabled) return;
    
    ditherFrame = (ditherFrame + 1) & 15; // 16-frame cycle
    
    for (uint16_t i = 0; i < numLeds; i++) {
      // Add sub-bit precision based on position and frame
      uint8_t ditherAmount = (i + ditherFrame) & 15;
      
      // Apply dither to each channel
      if (leds[i].r > 0 && leds[i].r < 255) {
        leds[i].r = qadd8(leds[i].r, (ditherAmount < 8) ? 1 : 0);
      }
      if (leds[i].g > 0 && leds[i].g < 255) {
        leds[i].g = qadd8(leds[i].g, (ditherAmount < 4) ? 1 : 0);
      }
      if (leds[i].b > 0 && leds[i].b < 255) {
        leds[i].b = qadd8(leds[i].b, (ditherAmount < 12) ? 1 : 0);
      }
    }
  }
  
  // 4. PARALLEL OUTPUT - Use multiple pins for faster refresh
  void setupParallelOutput() {
    #ifdef FASTLED_ESP32_I2S
    // ESP32 can drive up to 24 parallel outputs!
    Serial.println(F("[OPT] ESP32 I2S parallel output enabled"));
    
    // Example: Split 81 LEDs across 3 pins for 3x speed
    // FastLED.addLeds<WS2812, 6, GRB>(leds, 0, 27);
    // FastLED.addLeds<WS2812, 7, GRB>(leds, 27, 27);
    // FastLED.addLeds<WS2812, 8, GRB>(leds, 54, 27);
    #endif
  }
  
  // 5. BRIGHTNESS SCALING MODES
  void setScalingMode(bool videoMode = true) {
    // Video mode preserves color ratios better
    if (videoMode) {
      FastLED.setMaxRefreshRate(0); // Unlimited
      Serial.println(F("[OPT] Video brightness scaling enabled"));
    } else {
      FastLED.setMaxRefreshRate(400); // Limit for stability
      Serial.println(F("[OPT] Linear brightness scaling enabled"));
    }
  }
  
  // 6. GAMMA CORRECTION - Better color perception
  void applyGammaCorrection(CRGB* leds, uint16_t numLeds, float gamma = 2.2) {
    for (uint16_t i = 0; i < numLeds; i++) {
      leds[i].r = applyGamma_video(leds[i].r, gamma);
      leds[i].g = applyGamma_video(leds[i].g, gamma);
      leds[i].b = applyGamma_video(leds[i].b, gamma);
    }
  }
  
  // 7. NON-BLOCKING SHOW with callback
  void showNonBlocking(std::function<void()> callback = nullptr) {
    #ifdef FASTLED_ESP32_I2S
    // ESP32 can do async LED updates
    FastLED.show();
    if (callback) {
      // Do other work while LEDs update
      callback();
    }
    #else
    FastLED.show();
    #endif
  }
  
  // 8. VSYNC-LIKE FRAME LIMITING
  class FrameLimiter {
    uint32_t frameInterval;
    uint32_t lastFrameTime;
    uint32_t targetFPS;
    
  public:
    FrameLimiter(uint16_t fps = 60) : 
      targetFPS(fps),
      frameInterval(1000000 / fps),
      lastFrameTime(0) {}
    
    bool ready() {
      uint32_t now = micros();
      if (now - lastFrameTime >= frameInterval) {
        lastFrameTime = now;
        return true;
      }
      return false;
    }
    
    void sync() {
      while (!ready()) {
        // Tight loop wait
        yield();
      }
    }
    
    uint32_t getFrameTime() const {
      return micros() - lastFrameTime;
    }
  };
  
  // 9. COMPILE-TIME OPTIMIZATIONS
  void applyCompileTimeOptimizations() {
    // These are automatically applied when defined before including FastLED.h:
    
    // #define FASTLED_ALLOW_INTERRUPTS 0      // Disable interrupts during show()
    // #define FASTLED_INTERRUPT_RETRY_COUNT 1 // Minimize interrupt recovery
    // #define FASTLED_ESP32_I2S               // Use I2S parallel output on ESP32
    // #define FASTLED_RMT_BUILTIN_DRIVER 1    // Use built-in RMT driver
    // #define FASTLED_RMT_MAX_CHANNELS 8      // Maximum RMT channels
    // #define FASTLED_ESP32_FLASH_LOCK 0      // Disable flash locks for speed
    
    Serial.println(F("[OPT] Compile-time optimizations active"));
  }
  
  // 10. MEMORY OPTIMIZATION - Palette compression
  void compressPalette(const CRGBPalette16& source, CRGBPalette256& dest) {
    // Expand 16-entry palette to 256 with smooth interpolation
    for (uint16_t i = 0; i < 256; i++) {
      dest[i] = ColorFromPalette(source, i);
    }
  }
  
  // 11. ANTI-ALIASING for smoother animations
  void applyAntiAliasing(CRGB* leds, uint16_t numLeds) {
    CRGB prev = leds[0];
    
    for (uint16_t i = 1; i < numLeds - 1; i++) {
      CRGB current = leds[i];
      CRGB next = leds[i + 1];
      
      // Simple 3-tap filter
      leds[i].r = (prev.r + current.r * 2 + next.r) >> 2;
      leds[i].g = (prev.g + current.g * 2 + next.g) >> 2;
      leds[i].b = (prev.b + current.b * 2 + next.b) >> 2;
      
      prev = current;
    }
  }
  
  // 12. NOISE REDUCTION
  void reduceTemporalNoise(CRGB* leds, CRGB* lastFrame, uint16_t numLeds, uint8_t threshold = 8) {
    for (uint16_t i = 0; i < numLeds; i++) {
      // Only update LED if change is significant
      int16_t dr = abs(leds[i].r - lastFrame[i].r);
      int16_t dg = abs(leds[i].g - lastFrame[i].g);
      int16_t db = abs(leds[i].b - lastFrame[i].b);
      
      if (dr < threshold) leds[i].r = lastFrame[i].r;
      if (dg < threshold) leds[i].g = lastFrame[i].g;
      if (db < threshold) leds[i].b = lastFrame[i].b;
      
      lastFrame[i] = leds[i];
    }
  }
  
  // 13. PERCEPTUAL COLOR OPTIMIZATION
  void optimizeForHumanVision(CRGB* leds, uint16_t numLeds) {
    for (uint16_t i = 0; i < numLeds; i++) {
      // Boost reds slightly (human eye less sensitive)
      leds[i].r = qadd8(leds[i].r, leds[i].r >> 4);
      
      // Reduce blues slightly (human eye more sensitive)
      leds[i].b = qsub8(leds[i].b, leds[i].b >> 5);
    }
  }
  
  // 14. ADVANCED BLEND MODES
  static CRGB blendScreen(CRGB a, CRGB b) {
    return CRGB(
      255 - (((255 - a.r) * (255 - b.r)) >> 8),
      255 - (((255 - a.g) * (255 - b.g)) >> 8),
      255 - (((255 - a.b) * (255 - b.b)) >> 8)
    );
  }
  
  static CRGB blendOverlay(CRGB a, CRGB b) {
    return CRGB(
      a.r < 128 ? (2 * a.r * b.r) >> 8 : 255 - ((2 * (255 - a.r) * (255 - b.r)) >> 8),
      a.g < 128 ? (2 * a.g * b.g) >> 8 : 255 - ((2 * (255 - a.g) * (255 - b.g)) >> 8),
      a.b < 128 ? (2 * a.b * b.b) >> 8 : 255 - ((2 * (255 - a.b) * (255 - b.b)) >> 8)
    );
  }
  
  // 15. PSYCHEDELIC COLOR CYCLING
  void psychedelicColorCycle(CRGB* leds, uint16_t numLeds, uint8_t speed = 1) {
    static uint8_t hueOffset = 0;
    hueOffset += speed;
    
    for (uint16_t i = 0; i < numLeds; i++) {
      // Convert to HSV, modify hue, convert back
      CHSV hsv = rgb2hsv_approximate(leds[i]);
      hsv.h += hueOffset + (i * 2);
      leds[i] = hsv;
    }
  }
  
  // Print optimization summary
  void printOptimizationSummary() {
    Serial.println(F("\n=== FASTLED OPTIMIZATIONS ==="));
    Serial.print(F("Power Limit: "));
    Serial.print(maxPowerInMilliWatts);
    Serial.println(F(" mW"));
    
    Serial.print(F("Temporal Dithering: "));
    Serial.println(temporalDitheringEnabled ? F("ON") : F("OFF"));
    
    Serial.print(F("Color Temperature: "));
    Serial.println(F("Tungsten 40W"));
    
    Serial.print(F("Refresh Rate: "));
    Serial.print(FastLED.getFPS());
    Serial.println(F(" FPS"));
    
    #ifdef FASTLED_ESP32_I2S
    Serial.println(F("I2S Parallel Output: ENABLED"));
    #endif
    
    #ifdef FASTLED_ALLOW_INTERRUPTS
    Serial.println(F("Interrupt Protection: REDUCED"));
    #endif
    
    Serial.println(F("=============================\n"));
  }
};

// Gamma correction tables (stored in PROGMEM)
const uint8_t PROGMEM FastLEDOptimizer::gamma8[] = {
    0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
    0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  1,  1,  1,  1,
    1,  1,  1,  1,  1,  1,  1,  1,  1,  2,  2,  2,  2,  2,  2,  2,
    2,  3,  3,  3,  3,  3,  3,  3,  4,  4,  4,  4,  4,  5,  5,  5,
    5,  6,  6,  6,  6,  7,  7,  7,  7,  8,  8,  8,  9,  9,  9, 10,
   10, 10, 11, 11, 11, 12, 12, 13, 13, 13, 14, 14, 15, 15, 16, 16,
   17, 17, 18, 18, 19, 19, 20, 20, 21, 21, 22, 22, 23, 24, 24, 25,
   25, 26, 27, 27, 28, 29, 29, 30, 31, 32, 32, 33, 34, 35, 35, 36,
   37, 38, 39, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 50,
   51, 52, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 66, 67, 68,
   69, 70, 72, 73, 74, 75, 77, 78, 79, 81, 82, 83, 85, 86, 87, 89,
   90, 92, 93, 95, 96, 98, 99,101,102,104,105,107,109,110,112,114,
  115,117,119,120,122,124,126,127,129,131,133,135,137,138,140,142,
  144,146,148,150,152,154,156,158,160,162,164,167,169,171,173,175,
  177,180,182,184,186,189,191,193,196,198,200,203,205,208,210,213,
  215,218,220,223,225,228,231,233,236,239,241,244,247,249,252,255
};

// Global optimizer instance
extern FastLEDOptimizer fastLEDOpt;

#endif // FASTLED_OPTIMIZATIONS_H