#include "FxWave.h"

// Global FxWave2D instance
FxWave2D fxWave2D;

// Static variables for timing
static uint32_t lastUpdateTime = 0;

// Ripple effect - single center ripple
void displayFxWaveRipple() {
  static bool initialized = false;
  static uint32_t lastRippleTime = 0;
  
  if (!initialized) {
    fxWave2D.setupRipplePattern();
    initialized = true;
    lastUpdateTime = millis();
  }
  
  // Add new ripples periodically
  uint32_t now = millis();
  if (now - lastRippleTime > 2000) { // Every 2 seconds
    fxWave2D.resetWaves();
    fxWave2D.addWaveSource(0.5f, 0.5f, 0.8f, 1.2f, 2.0f, 
                           ColorFromPalette(currentPalette, random8()));
    lastRippleTime = now;
  }
  
  // Update simulation
  uint32_t deltaTime = now - lastUpdateTime;
  lastUpdateTime = now;
  
  fxWave2D.update(deltaTime);
  fxWave2D.render();
}

// Interference pattern - multiple wave sources
void displayFxWaveInterference() {
  static bool initialized = false;
  
  if (!initialized) {
    fxWave2D.setupInterferencePattern();
    initialized = true;
    lastUpdateTime = millis();
  }
  
  // Update simulation
  uint32_t now = millis();
  uint32_t deltaTime = now - lastUpdateTime;
  lastUpdateTime = now;
  
  fxWave2D.update(deltaTime);
  fxWave2D.render();
}

// Orbital pattern - moving wave sources
void displayFxWaveOrbital() {
  static uint32_t lastResetTime = 0;
  
  uint32_t now = millis();
  
  // Reset and update orbital positions every frame
  if (now - lastResetTime > 50) { // Update every 50ms
    fxWave2D.resetWaves();
  
    float time = now * 0.001f;
    float x1 = 0.5f + 0.3f * cos(time * 0.5f);
    float y1 = 0.5f + 0.3f * sin(time * 0.5f);
    float x2 = 0.5f + 0.3f * cos(time * -0.7f + PI);
    float y2 = 0.5f + 0.3f * sin(time * -0.7f + PI);
    
    // Get colors from current palette
    uint8_t colorIndex1 = (now / 20) & 255;
    uint8_t colorIndex2 = (now / 20 + 128) & 255;
    
    CRGB color1 = ColorFromPalette(currentPalette, colorIndex1);
    CRGB color2 = ColorFromPalette(currentPalette, colorIndex2);
    
    fxWave2D.addWaveSource(x1, y1, 1.2f, 0.9f, 2.5f, color1);
    fxWave2D.addWaveSource(x2, y2, 1.2f, 0.9f, 2.5f, color2);
    
    lastResetTime = now;
  }
  
  // Update simulation
  uint32_t deltaTime = now - lastUpdateTime;
  lastUpdateTime = now;
  
  fxWave2D.update(deltaTime);
  fxWave2D.render();
}