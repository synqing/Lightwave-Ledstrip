#ifndef FX_WAVE_H
#define FX_WAVE_H

#include <FastLED.h>
#include "Config.h"
#include "StripMap.h"

// External variables
extern CRGB leds[TOTAL_LEDS];
extern uint8_t angles[TOTAL_LEDS];
extern uint8_t radii[TOTAL_LEDS];
extern CRGBPalette16 currentPalette;
extern uint8_t fadeAmount;
extern uint8_t paletteSpeed;

// Wave simulation parameters
struct WaveSource {
  float x, y;           // Position in normalized coordinates (0.0-1.0)
  float frequency;      // Wave frequency
  float amplitude;      // Wave amplitude
  float phase;          // Current phase
  float speed;          // Phase increment speed
  CRGB color;          // Wave color
  bool active;         // Is this source active
};

// FxWave 2D wave simulator class
class FxWave2D {
private:
  static const uint8_t MAX_WAVE_SOURCES = 6;
  WaveSource waveSources[MAX_WAVE_SOURCES];
  uint8_t numActiveSources = 0;
  
  // 2D coordinate mapping for 1D strip
  float ledPositions[TOTAL_LEDS][2]; // [x, y] normalized coordinates
  
  // Wave calculation buffers
  float waveHeights[TOTAL_LEDS];
  float dampingField[TOTAL_LEDS];
  
  // Simulation parameters
  float timeScale = 1.0f;
  float globalDamping = 0.95f;
  bool useReflection = true;
  
public:
  FxWave2D() {
    initializeMapping();
    resetWaves();
  }
  
  // Initialize 2D coordinate mapping for LEDs on crystal surface
  void initializeMapping() {
    // Map LEDs to approximate crystal surface coordinates
    // Using golden spiral pattern for natural crystal mapping
    const float PHI = 1.618033988749f; // Golden ratio
    
    for (uint16_t i = 0; i < TOTAL_LEDS; i++) {
      float theta = i * 2.0f * PI / PHI;
      float radius = sqrt(float(i) / float(TOTAL_LEDS));
      
      // Convert polar to cartesian and normalize to [0,1]
      ledPositions[i][0] = 0.5f + 0.4f * radius * cos(theta);
      ledPositions[i][1] = 0.5f + 0.4f * radius * sin(theta);
      
      // Clamp to valid range
      ledPositions[i][0] = constrain(ledPositions[i][0], 0.0f, 1.0f);
      ledPositions[i][1] = constrain(ledPositions[i][1], 0.0f, 1.0f);
      
      // Initialize damping field (higher at edges)
      float distFromCenter = sqrt(pow(ledPositions[i][0] - 0.5f, 2) + 
                                  pow(ledPositions[i][1] - 0.5f, 2));
      dampingField[i] = 1.0f - (distFromCenter * 0.3f);
    }
  }
  
  // Add a wave source
  bool addWaveSource(float x, float y, float freq, float amp, float speed, CRGB color) {
    if (numActiveSources >= MAX_WAVE_SOURCES) return false;
    
    for (uint8_t i = 0; i < MAX_WAVE_SOURCES; i++) {
      if (!waveSources[i].active) {
        waveSources[i] = {x, y, freq, amp, 0.0f, speed, color, true};
        numActiveSources++;
        return true;
      }
    }
    return false;
  }
  
  // Remove all wave sources
  void resetWaves() {
    for (uint8_t i = 0; i < MAX_WAVE_SOURCES; i++) {
      waveSources[i].active = false;
    }
    numActiveSources = 0;
    memset(waveHeights, 0, sizeof(waveHeights));
  }
  
  // Update wave simulation
  void update(uint32_t deltaTime) {
    float dt = deltaTime * timeScale * 0.001f;
    
    // Clear wave heights
    memset(waveHeights, 0, sizeof(waveHeights));
    
    // Calculate waves from all active sources
    for (uint8_t src = 0; src < MAX_WAVE_SOURCES; src++) {
      if (!waveSources[src].active) continue;
      
      WaveSource& wave = waveSources[src];
      wave.phase += wave.speed * dt;
      
      // Calculate wave contribution for each LED
      for (uint16_t led = 0; led < TOTAL_LEDS; led++) {
        float dx = ledPositions[led][0] - wave.x;
        float dy = ledPositions[led][1] - wave.y;
        float distance = sqrt(dx * dx + dy * dy);
        
        // Wave equation: amplitude * sin(frequency * distance - phase)
        float waveValue = wave.amplitude * sin(wave.frequency * distance * 10.0f - wave.phase);
        
        // Apply distance attenuation
        float attenuation = 1.0f / (1.0f + distance * 2.0f);
        waveValue *= attenuation;
        
        // Apply damping field
        waveValue *= dampingField[led];
        
        // Accumulate wave contributions
        waveHeights[led] += waveValue;
      }
    }
    
    // Apply global damping
    for (uint16_t i = 0; i < TOTAL_LEDS; i++) {
      waveHeights[i] *= globalDamping;
    }
  }
  
  // Render wave simulation to LED strip
  void render() {
    // Apply fade for trailing effect
    uint8_t effectiveFade = constrain(fadeAmount, 5, 100);
    fadeToBlackBy(leds, TOTAL_LEDS, effectiveFade);
    
    for (uint16_t i = 0; i < TOTAL_LEDS; i++) {
      float height = waveHeights[i];
      
      if (abs(height) > 0.01f) {
        // Convert wave height to brightness (0-255)
        uint8_t brightness = constrain(abs(height) * 255.0f, 0, 255);
        
        // Color mixing from all contributing sources
        CRGB pixelColor = CRGB::Black;
        float totalContribution = 0.0f;
        
        for (uint8_t src = 0; src < MAX_WAVE_SOURCES; src++) {
          if (!waveSources[src].active) continue;
          
          WaveSource& wave = waveSources[src];
          float dx = ledPositions[i][0] - wave.x;
          float dy = ledPositions[i][1] - wave.y;
          float distance = sqrt(dx * dx + dy * dy);
          
          float contribution = wave.amplitude / (1.0f + distance * 3.0f);
          if (contribution > 0.1f) {
            float weight = contribution / (contribution + totalContribution);
            pixelColor = blend(pixelColor, wave.color, weight * 255);
            totalContribution += contribution;
          }
        }
        
        if (totalContribution < 0.1f) {
          // Use palette if no strong source contribution
          uint8_t colorIndex = (millis() * paletteSpeed / 10 + i * 8) & 255;
          pixelColor = ColorFromPalette(currentPalette, colorIndex, brightness);
        } else {
          pixelColor.fadeToBlackBy(255 - brightness);
        }
        
        // Add to existing pixel (for additive blending)
        leds[i] += pixelColor;
      }
    }
  }
  
  // Preset configurations
  void setupRipplePattern() {
    resetWaves();
    addWaveSource(0.5f, 0.5f, 0.8f, 1.0f, 2.0f, CRGB::Blue);
    addWaveSource(0.3f, 0.3f, 1.2f, 0.7f, 1.5f, CRGB::Cyan);
  }
  
  void setupInterferencePattern() {
    resetWaves();
    addWaveSource(0.2f, 0.2f, 1.0f, 0.8f, 1.8f, CRGB::Red);
    addWaveSource(0.8f, 0.8f, 1.0f, 0.8f, 1.8f, CRGB::Blue);
    addWaveSource(0.2f, 0.8f, 1.2f, 0.6f, 2.2f, CRGB::Green);
    addWaveSource(0.8f, 0.2f, 1.2f, 0.6f, 2.2f, CRGB::Purple);
  }
  
  void setupOrbitalPattern() {
    resetWaves();
    // Moving wave sources (updated in render loop)
    float time = millis() * 0.001f;
    float x1 = 0.5f + 0.3f * cos(time * 0.5f);
    float y1 = 0.5f + 0.3f * sin(time * 0.5f);
    float x2 = 0.5f + 0.3f * cos(time * -0.7f + PI);
    float y2 = 0.5f + 0.3f * sin(time * -0.7f + PI);
    
    addWaveSource(x1, y1, 1.5f, 0.9f, 2.5f, CRGB::Orange);
    addWaveSource(x2, y2, 1.5f, 0.9f, 2.5f, CRGB::Cyan);
  }
  
  // Setters
  void setTimeScale(float scale) { timeScale = constrain(scale, 0.1f, 5.0f); }
  void setGlobalDamping(float damping) { globalDamping = constrain(damping, 0.1f, 1.0f); }
  void setReflection(bool enabled) { useReflection = enabled; }
  
  // Getters
  uint8_t getNumActiveSources() const { return numActiveSources; }
  float getTimeScale() const { return timeScale; }
};

// Global FxWave2D instance
extern FxWave2D fxWave2D;

// Effect functions using FxWave2D
void displayFxWaveRipple();
void displayFxWaveInterference();
void displayFxWaveOrbital();

#endif // FX_WAVE_H