#ifndef PIPELINE_EFFECTS_H
#define PIPELINE_EFFECTS_H

#include "VisualPipeline.h"
#include "Config.h"

// External variables
extern CRGB leds[TOTAL_LEDS];
extern CRGBPalette16 currentPalette;
extern uint8_t currentPaletteIndex;
extern uint8_t fadeAmount;
extern uint8_t paletteSpeed;
extern uint8_t brightnessVal;
extern uint8_t angles[TOTAL_LEDS];
extern uint8_t radii[TOTAL_LEDS];

// ===== CUSTOM PIPELINE STAGES =====

// Fibonacci spiral stage - uses angle/radius mapping
class FibonacciStage : public PipelineStage {
  float spiralSpeed;
  float colorSpeed;
  
public:
  FibonacciStage() : 
    PipelineStage("Fibonacci"),
    spiralSpeed(1.0f),
    colorSpeed(1.0f) {}
  
  void process(RenderContext& ctx) override {
    if (!enabled) return;
    
    uint16_t time16 = ctx.frameNumber * spiralSpeed;
    
    for (uint16_t i = 0; i < ctx.numLeds; i++) {
      // Use pre-calculated angle/radius arrays
      uint8_t angle = angles[i];
      uint8_t radius = radii[i];
      
      // Create spiral pattern
      uint16_t spiralOffset = (angle * 4) + (radius * 2) + time16;
      uint8_t brightness = sin8(spiralOffset >> 2);
      
      // Color from palette with movement
      uint8_t colorIndex = angle + (time16 >> 6) * colorSpeed;
      
      CRGB color = ColorFromPalette(*ctx.palette, colorIndex, brightness);
      
      // Apply radius-based intensity
      color.nscale8(radius);
      
      ctx.framebuffer[i] = color;
    }
  }
  
  void updateParams(float param1, float param2, float param3) override {
    spiralSpeed = param1 * 5.0f;
    colorSpeed = param2 * 5.0f;
  }
};

// Audio visualization placeholder stage
class AudioVisualizerStage : public PipelineStage {
  uint8_t bands[8];  // Frequency bands
  float decay;
  
public:
  AudioVisualizerStage() : 
    PipelineStage("AudioViz"),
    decay(0.9f) {
    memset(bands, 0, sizeof(bands));
  }
  
  void process(RenderContext& ctx) override {
    if (!enabled) return;
    
    // Simulate audio (replace with real FFT data)
    static uint32_t audioTime = 0;
    audioTime += ctx.deltaTime;
    
    // Update fake frequency bands
    for (uint8_t i = 0; i < 8; i++) {
      uint8_t newValue = sin8((audioTime >> (4 + i)) + (i * 32));
      bands[i] = bands[i] * decay + newValue * (1.0f - decay);
    }
    
    // Map frequency bands to LED positions
    uint16_t ledsPerBand = ctx.numLeds / 8;
    
    for (uint16_t i = 0; i < ctx.numLeds; i++) {
      uint8_t band = i / ledsPerBand;
      if (band >= 8) band = 7;
      
      uint8_t intensity = bands[band];
      uint8_t colorIndex = band * 32;
      
      CRGB color = ColorFromPalette(*ctx.palette, colorIndex, intensity);
      ctx.framebuffer[i] = color;
    }
  }
  
  void setAudioData(uint8_t* fftData, uint8_t numBands) {
    // Copy real FFT data
    uint8_t bandsToUpdate = min(numBands, (uint8_t)8);
    for (uint8_t i = 0; i < bandsToUpdate; i++) {
      bands[i] = fftData[i];
    }
  }
};

// Matrix/grid effect stage
class MatrixStage : public PipelineStage {
  struct Drop {
    float position;
    float speed;
    uint8_t length;
    uint8_t hue;
    bool active;
  };
  
  static const uint8_t MAX_DROPS = 10;
  Drop drops[MAX_DROPS];
  
public:
  MatrixStage() : PipelineStage("Matrix") {
    for (uint8_t i = 0; i < MAX_DROPS; i++) {
      drops[i].active = false;
    }
  }
  
  void process(RenderContext& ctx) override {
    if (!enabled) return;
    
    // Fade existing trails
    fadeToBlackBy(ctx.framebuffer, ctx.numLeds, 50);
    
    // Spawn new drops
    if (random8() < 30) {
      spawnDrop();
    }
    
    // Update drops
    for (uint8_t i = 0; i < MAX_DROPS; i++) {
      if (!drops[i].active) continue;
      
      Drop& d = drops[i];
      d.position += d.speed * ctx.deltaTime * 0.01f;
      
      if (d.position >= ctx.numLeds + d.length) {
        d.active = false;
        continue;
      }
      
      // Render drop with trail
      for (uint8_t j = 0; j < d.length; j++) {
        int16_t ledPos = d.position - j;
        if (ledPos >= 0 && ledPos < ctx.numLeds) {
          uint8_t brightness = 255 - (j * 255 / d.length);
          CRGB color = CHSV(d.hue, 255 - (j * 50), brightness);
          ctx.framebuffer[ledPos] += color;
        }
      }
    }
  }
  
private:
  void spawnDrop() {
    for (uint8_t i = 0; i < MAX_DROPS; i++) {
      if (!drops[i].active) {
        drops[i].position = -5;
        drops[i].speed = 5.0f + random8(10);
        drops[i].length = 5 + random8(10);
        drops[i].hue = 96 + random8(32); // Green-ish
        drops[i].active = true;
        break;
      }
    }
  }
};

// Reaction-diffusion simulation stage
class ReactionDiffusionStage : public PipelineStage {
  float* stateA;
  float* stateB;
  float feedRate;
  float killRate;
  float diffusionA;
  float diffusionB;
  
public:
  ReactionDiffusionStage() : 
    PipelineStage("ReactionDiffusion"),
    feedRate(0.055f),
    killRate(0.062f),
    diffusionA(1.0f),
    diffusionB(0.5f) {
    stateA = new float[TOTAL_LEDS];
    stateB = new float[TOTAL_LEDS];
    init();
  }
  
  ~ReactionDiffusionStage() {
    delete[] stateA;
    delete[] stateB;
  }
  
  void init() override {
    // Initialize with random seed points
    for (uint16_t i = 0; i < TOTAL_LEDS; i++) {
      stateA[i] = 1.0f;
      stateB[i] = 0.0f;
    }
    
    // Add some B seeds
    for (uint8_t i = 0; i < 5; i++) {
      uint16_t pos = random(TOTAL_LEDS);
      stateB[pos] = 1.0f;
    }
  }
  
  void process(RenderContext& ctx) override {
    if (!enabled) return;
    
    float* newA = ctx.floatBuffer;
    float* newB = (float*)ctx.maskBuffer;  // Reuse mask buffer
    
    if (!newA) {
      ctx.floatBuffer = new float[ctx.numLeds];
      newA = ctx.floatBuffer;
    }
    if (!newB) {
      ctx.maskBuffer = new uint8_t[ctx.numLeds * sizeof(float)];
      newB = (float*)ctx.maskBuffer;
    }
    
    // Gray-Scott reaction-diffusion
    for (uint16_t i = 0; i < ctx.numLeds; i++) {
      float a = stateA[i];
      float b = stateB[i];
      
      // Get neighbors (1D laplacian)
      float lapA = 0, lapB = 0;
      if (i > 0) {
        lapA += stateA[i-1] - a;
        lapB += stateB[i-1] - b;
      }
      if (i < ctx.numLeds - 1) {
        lapA += stateA[i+1] - a;
        lapB += stateB[i+1] - b;
      }
      
      // Reaction-diffusion equations
      float reaction = a * b * b;
      newA[i] = a + (diffusionA * lapA - reaction + feedRate * (1.0f - a)) * 0.1f;
      newB[i] = b + (diffusionB * lapB + reaction - (killRate + feedRate) * b) * 0.1f;
      
      // Constrain values
      newA[i] = constrain(newA[i], 0.0f, 1.0f);
      newB[i] = constrain(newB[i], 0.0f, 1.0f);
      
      // Visualize
      uint8_t brightness = (newB[i] - newA[i] + 1.0f) * 127.5f;
      uint8_t colorIndex = brightness + (ctx.frameNumber >> 2);
      ctx.framebuffer[i] = ColorFromPalette(*ctx.palette, colorIndex, brightness);
    }
    
    // Swap buffers
    memcpy(stateA, newA, ctx.numLeds * sizeof(float));
    memcpy(stateB, newB, ctx.numLeds * sizeof(float));
  }
};

// ===== PIPELINE EFFECT WRAPPERS =====

// Global pipeline instances
VisualPipeline* gradientPipeline = nullptr;
VisualPipeline* fibonacciPipeline = nullptr;
VisualPipeline* audioPipeline = nullptr;
VisualPipeline* matrixPipeline = nullptr;
VisualPipeline* reactionPipeline = nullptr;

// Initialize all pipelines
void initPipelines() {
  // Gradient pipeline
  gradientPipeline = new VisualPipeline(leds, TOTAL_LEDS);
  gradientPipeline->addStage(new GradientStage());
  gradientPipeline->addStage(new BrightnessStage());
  gradientPipeline->addStage(new FadeStage());
  
  // Fibonacci pipeline
  fibonacciPipeline = new VisualPipeline(leds, TOTAL_LEDS);
  fibonacciPipeline->addStage(new FibonacciStage());
  fibonacciPipeline->addStage(new BlurStage(32));
  fibonacciPipeline->addStage(new FadeStage());
  
  // Audio visualizer pipeline
  audioPipeline = new VisualPipeline(leds, TOTAL_LEDS);
  audioPipeline->addStage(new AudioVisualizerStage());
  audioPipeline->addStage(new BlurStage(64));
  audioPipeline->addStage(new ParticleStage());
  
  // Matrix rain pipeline
  matrixPipeline = new VisualPipeline(leds, TOTAL_LEDS);
  matrixPipeline->addStage(new MatrixStage());
  matrixPipeline->addStage(new BlurStage(20));
  
  // Reaction-diffusion pipeline
  reactionPipeline = new VisualPipeline(leds, TOTAL_LEDS);
  reactionPipeline->addStage(new ReactionDiffusionStage());
  reactionPipeline->addStage(new BlurStage(40));
}

// Effect wrapper functions for FxEngine
void displayPipelineGradient() {
  static uint32_t lastTime = millis();
  uint32_t now = millis();
  uint32_t deltaTime = now - lastTime;
  lastTime = now;
  
  if (gradientPipeline) {
    gradientPipeline->updateGlobalParams(brightnessVal, fadeAmount, paletteSpeed, &currentPalette);
    gradientPipeline->execute(deltaTime);
  }
}

void displayPipelineFibonacci() {
  static uint32_t lastTime = millis();
  uint32_t now = millis();
  uint32_t deltaTime = now - lastTime;
  lastTime = now;
  
  if (fibonacciPipeline) {
    fibonacciPipeline->updateGlobalParams(brightnessVal, fadeAmount, paletteSpeed, &currentPalette);
    fibonacciPipeline->execute(deltaTime);
  }
}

void displayPipelineAudio() {
  static uint32_t lastTime = millis();
  uint32_t now = millis();
  uint32_t deltaTime = now - lastTime;
  lastTime = now;
  
  if (audioPipeline) {
    audioPipeline->updateGlobalParams(brightnessVal, fadeAmount, paletteSpeed, &currentPalette);
    audioPipeline->execute(deltaTime);
  }
}

void displayPipelineMatrix() {
  static uint32_t lastTime = millis();
  uint32_t now = millis();
  uint32_t deltaTime = now - lastTime;
  lastTime = now;
  
  if (matrixPipeline) {
    matrixPipeline->updateGlobalParams(brightnessVal, fadeAmount, paletteSpeed, &currentPalette);
    matrixPipeline->execute(deltaTime);
  }
}

void displayPipelineReaction() {
  static uint32_t lastTime = millis();
  uint32_t now = millis();
  uint32_t deltaTime = now - lastTime;
  lastTime = now;
  
  if (reactionPipeline) {
    reactionPipeline->updateGlobalParams(brightnessVal, fadeAmount, paletteSpeed, &currentPalette);
    reactionPipeline->execute(deltaTime);
  }
}

// Clean up pipelines
void cleanupPipelines() {
  delete gradientPipeline;
  delete fibonacciPipeline;
  delete audioPipeline;
  delete matrixPipeline;
  delete reactionPipeline;
}

#endif // PIPELINE_EFFECTS_H