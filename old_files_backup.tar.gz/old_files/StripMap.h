#ifndef STRIP_MAP_H
#define STRIP_MAP_H

#include <stdint.h>
#include "Config.h"

// Arrays for effect parameters
extern uint8_t angles[TOTAL_LEDS];          // Angular position for circular/wave effects
extern uint8_t radii[TOTAL_LEDS];           // Distance from center for circular effects

// Initialize the arrays for strip mapping
inline void initStripMapping() {
    for (int i = 0; i < TOTAL_LEDS; i++) {
        // Convert linear position to angle (0-255)
        // This creates a full 0-255 cycle along the strip
        angles[i] = (i * 256) / TOTAL_LEDS;
        
        // Set radius based on position
        // Center LEDs are brightest, edges dimmer
        uint8_t mid = TOTAL_LEDS / 2;
        uint8_t distance = (i < mid) ? (mid - i) : (i - mid);
        uint8_t normalizedDistance = (distance * 255) / mid;
        radii[i] = 255 - normalizedDistance;
    }
}

// Functions for creating wave and pattern effects on strips
inline uint8_t getAngleForPosition(uint16_t position, uint16_t totalLength) {
    return (position * 256) / totalLength;
}

#endif 