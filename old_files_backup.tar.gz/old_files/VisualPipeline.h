#ifndef VISUAL_PIPELINE_H
#define VISUAL_PIPELINE_H

#include <FastLED.h>
#include "Config.h"
#include <vector>
#include <functional>

// Forward declarations
class PipelineStage;
class RenderContext;

// Render context passed through the pipeline
class RenderContext {
public:
  CRGB* framebuffer;          // Primary render target
  CRGB* scratchBuffer;        // Temporary buffer for effects
  uint16_t numLeds;           // Number of LEDs
  uint32_t frameNumber;       // Current frame number
  uint32_t deltaTime;         // Time since last frame (ms)
  float timeSeconds;          // Total time in seconds
  
  // Global parameters accessible to all stages
  uint8_t brightness;
  uint8_t fadeAmount;
  uint8_t speed;
  CRGBPalette16* palette;
  
  // Optional buffers for advanced effects
  float* floatBuffer;         // For HDR/precision effects
  uint8_t* maskBuffer;        // For masking/blending
  
  // Metadata
  void* userData;             // Stage-specific data
  
  RenderContext(CRGB* fb, uint16_t leds) : 
    framebuffer(fb), 
    numLeds(leds),
    frameNumber(0),
    deltaTime(0),
    timeSeconds(0),
    brightness(255),
    fadeAmount(20),
    speed(10),
    palette(nullptr),
    floatBuffer(nullptr),
    maskBuffer(nullptr),
    userData(nullptr) {
    // Allocate scratch buffer
    scratchBuffer = new CRGB[leds];
  }
  
  ~RenderContext() {
    delete[] scratchBuffer;
    if (floatBuffer) delete[] floatBuffer;
    if (maskBuffer) delete[] maskBuffer;
  }
  
  // Swap framebuffer with scratch buffer
  void swapBuffers() {
    CRGB* temp = framebuffer;
    framebuffer = scratchBuffer;
    scratchBuffer = temp;
  }
  
  // Clear a buffer
  void clearBuffer(CRGB* buffer) {
    memset(buffer, 0, numLeds * sizeof(CRGB));
  }
  
  // Copy buffer
  void copyBuffer(CRGB* src, CRGB* dst) {
    memcpy(dst, src, numLeds * sizeof(CRGB));
  }
};

// Base class for all pipeline stages
class PipelineStage {
protected:
  String name;
  bool enabled;
  float mixAmount;  // 0.0 to 1.0 blend factor
  
public:
  PipelineStage(const String& stageName) : 
    name(stageName), 
    enabled(true), 
    mixAmount(1.0f) {}
  
  virtual ~PipelineStage() {}
  
  // Main processing function - must be implemented
  virtual void process(RenderContext& ctx) = 0;
  
  // Optional initialization
  virtual void init() {}
  
  // Optional cleanup
  virtual void cleanup() {}
  
  // Optional parameter update
  virtual void updateParams(float param1, float param2, float param3) {}
  
  // Getters/Setters
  void setEnabled(bool en) { enabled = en; }
  bool isEnabled() const { return enabled; }
  void setMixAmount(float mix) { mixAmount = constrain(mix, 0.0f, 1.0f); }
  float getMixAmount() const { return mixAmount; }
  const String& getName() const { return name; }
};

// ===== GENERATOR STAGES =====

// Solid color generator
class SolidColorStage : public PipelineStage {
  CRGB color;
public:
  SolidColorStage(CRGB col = CRGB::Black) : 
    PipelineStage("SolidColor"), color(col) {}
  
  void process(RenderContext& ctx) override {
    if (!enabled) return;
    fill_solid(ctx.framebuffer, ctx.numLeds, color);
  }
  
  void setColor(CRGB col) { color = col; }
};

// Gradient generator
class GradientStage : public PipelineStage {
  uint8_t startHue, endHue;
  bool circular;
public:
  GradientStage() : 
    PipelineStage("Gradient"), 
    startHue(0), 
    endHue(255), 
    circular(false) {}
  
  void process(RenderContext& ctx) override {
    if (!enabled) return;
    
    for (uint16_t i = 0; i < ctx.numLeds; i++) {
      uint8_t pos = (i * 255) / ctx.numLeds;
      uint8_t hue = startHue + ((endHue - startHue) * pos / 255);
      if (circular) hue += ctx.frameNumber;
      ctx.framebuffer[i] = CHSV(hue, 255, 255);
    }
  }
  
  void updateParams(float param1, float param2, float param3) override {
    startHue = param1 * 255;
    endHue = param2 * 255;
    circular = param3 > 0.5f;
  }
};

// Palette generator
class PaletteStage : public PipelineStage {
  uint8_t offset;
  uint8_t stretch;
public:
  PaletteStage() : 
    PipelineStage("Palette"), 
    offset(0), 
    stretch(1) {}
  
  void process(RenderContext& ctx) override {
    if (!enabled || !ctx.palette) return;
    
    for (uint16_t i = 0; i < ctx.numLeds; i++) {
      uint8_t index = offset + (i * stretch);
      ctx.framebuffer[i] = ColorFromPalette(*ctx.palette, index);
    }
    offset += ctx.speed;
  }
};

// ===== MODIFIER STAGES =====

// Brightness modulation
class BrightnessStage : public PipelineStage {
  uint8_t (*brightnessFunction)(uint16_t index, uint32_t time);
  
public:
  BrightnessStage() : PipelineStage("Brightness") {
    // Default sine wave brightness
    brightnessFunction = [](uint16_t i, uint32_t t) -> uint8_t {
      return sin8((i * 4) + (t >> 2));
    };
  }
  
  void process(RenderContext& ctx) override {
    if (!enabled) return;
    
    for (uint16_t i = 0; i < ctx.numLeds; i++) {
      uint8_t bright = brightnessFunction(i, ctx.frameNumber);
      ctx.framebuffer[i].nscale8(bright);
    }
  }
  
  void setBrightnessFunction(uint8_t (*func)(uint16_t, uint32_t)) {
    brightnessFunction = func;
  }
};

// Fade/trail effect
class FadeStage : public PipelineStage {
public:
  FadeStage() : PipelineStage("Fade") {}
  
  void process(RenderContext& ctx) override {
    if (!enabled || ctx.fadeAmount == 0) return;
    fadeToBlackBy(ctx.framebuffer, ctx.numLeds, ctx.fadeAmount);
  }
};

// Blur effect
class BlurStage : public PipelineStage {
  uint8_t amount;
public:
  BlurStage(uint8_t blurAmount = 64) : 
    PipelineStage("Blur"), 
    amount(blurAmount) {}
  
  void process(RenderContext& ctx) override {
    if (!enabled || amount == 0) return;
    
    // Simple 1D blur
    ctx.copyBuffer(ctx.framebuffer, ctx.scratchBuffer);
    
    for (uint16_t i = 1; i < ctx.numLeds - 1; i++) {
      ctx.framebuffer[i] = blend(
        blend(ctx.scratchBuffer[i-1], ctx.scratchBuffer[i], 128),
        ctx.scratchBuffer[i+1], 
        amount
      );
    }
  }
};

// ===== COMPOSITOR STAGES =====

// Layer blending stage
class BlendStage : public PipelineStage {
public:
  enum BlendMode {
    BLEND_ADD,
    BLEND_MULTIPLY,
    BLEND_SCREEN,
    BLEND_OVERLAY,
    BLEND_DIFFERENCE
  };
  
private:
  BlendMode mode;
  CRGB* layer2;
  
public:
  BlendStage(BlendMode m = BLEND_ADD) : 
    PipelineStage("Blend"), 
    mode(m), 
    layer2(nullptr) {}
  
  void setSecondLayer(CRGB* layer) { layer2 = layer; }
  
  void process(RenderContext& ctx) override {
    if (!enabled || !layer2) return;
    
    for (uint16_t i = 0; i < ctx.numLeds; i++) {
      CRGB& base = ctx.framebuffer[i];
      CRGB& overlay = layer2[i];
      
      switch (mode) {
        case BLEND_ADD:
          base += overlay;
          break;
        case BLEND_MULTIPLY:
          base.r = (base.r * overlay.r) >> 8;
          base.g = (base.g * overlay.g) >> 8;
          base.b = (base.b * overlay.b) >> 8;
          break;
        case BLEND_SCREEN:
          base.r = 255 - (((255 - base.r) * (255 - overlay.r)) >> 8);
          base.g = 255 - (((255 - base.g) * (255 - overlay.g)) >> 8);
          base.b = 255 - (((255 - base.b) * (255 - overlay.b)) >> 8);
          break;
        case BLEND_OVERLAY:
          // Simplified overlay
          base = blend(base, overlay, 128);
          break;
        case BLEND_DIFFERENCE:
          base.r = abs(base.r - overlay.r);
          base.g = abs(base.g - overlay.g);
          base.b = abs(base.b - overlay.b);
          break;
      }
    }
  }
};

// ===== MAIN VISUAL PIPELINE =====

class VisualPipeline {
private:
  std::vector<PipelineStage*> stages;
  RenderContext* context;
  bool initialized;
  
  // Performance tracking
  uint32_t stageTimings[32]; // Max 32 stages
  
public:
  VisualPipeline(CRGB* framebuffer, uint16_t numLeds) : 
    context(nullptr), 
    initialized(false) {
    context = new RenderContext(framebuffer, numLeds);
  }
  
  ~VisualPipeline() {
    clear();
    delete context;
  }
  
  // Add a stage to the pipeline
  void addStage(PipelineStage* stage) {
    if (stages.size() < 32) {
      stages.push_back(stage);
      stage->init();
    }
  }
  
  // Insert stage at specific position
  void insertStage(size_t position, PipelineStage* stage) {
    if (position <= stages.size() && stages.size() < 32) {
      stages.insert(stages.begin() + position, stage);
      stage->init();
    }
  }
  
  // Remove stage by pointer
  void removeStage(PipelineStage* stage) {
    auto it = std::find(stages.begin(), stages.end(), stage);
    if (it != stages.end()) {
      (*it)->cleanup();
      stages.erase(it);
      delete stage;
    }
  }
  
  // Remove stage by index
  void removeStage(size_t index) {
    if (index < stages.size()) {
      stages[index]->cleanup();
      delete stages[index];
      stages.erase(stages.begin() + index);
    }
  }
  
  // Clear all stages
  void clear() {
    for (auto stage : stages) {
      stage->cleanup();
      delete stage;
    }
    stages.clear();
  }
  
  // Execute the pipeline
  void execute(uint32_t deltaMs) {
    if (!context) return;
    
    // Update context
    context->frameNumber++;
    context->deltaTime = deltaMs;
    context->timeSeconds += deltaMs * 0.001f;
    
    // Process each stage
    for (size_t i = 0; i < stages.size(); i++) {
      uint32_t startTime = micros();
      
      if (stages[i]->isEnabled()) {
        stages[i]->process(*context);
      }
      
      stageTimings[i] = micros() - startTime;
    }
  }
  
  // Get stage by index
  PipelineStage* getStage(size_t index) {
    return (index < stages.size()) ? stages[index] : nullptr;
  }
  
  // Get stage by name
  PipelineStage* getStage(const String& name) {
    for (auto stage : stages) {
      if (stage->getName() == name) {
        return stage;
      }
    }
    return nullptr;
  }
  
  // Get number of stages
  size_t getStageCount() const { return stages.size(); }
  
  // Get render context
  RenderContext* getContext() { return context; }
  
  // Update global parameters
  void updateGlobalParams(uint8_t brightness, uint8_t fade, 
                         uint8_t speed, CRGBPalette16* palette) {
    if (context) {
      context->brightness = brightness;
      context->fadeAmount = fade;
      context->speed = speed;
      context->palette = palette;
    }
  }
  
  // Print pipeline info
  void printPipelineInfo() {
    Serial.println(F("\n=== VISUAL PIPELINE ==="));
    Serial.print(F("Stages: "));
    Serial.println(stages.size());
    
    for (size_t i = 0; i < stages.size(); i++) {
      Serial.print(F("  "));
      Serial.print(i);
      Serial.print(F(". "));
      Serial.print(stages[i]->getName());
      Serial.print(F(" ["));
      Serial.print(stages[i]->isEnabled() ? "ON" : "OFF");
      Serial.print(F("] "));
      Serial.print(stageTimings[i]);
      Serial.println(F("μs"));
    }
    
    Serial.println(F("===================="));
  }
  
  // Create preset pipelines
  static VisualPipeline* createSimpleGradient(CRGB* fb, uint16_t leds) {
    VisualPipeline* pipe = new VisualPipeline(fb, leds);
    pipe->addStage(new GradientStage());
    pipe->addStage(new BrightnessStage());
    pipe->addStage(new FadeStage());
    return pipe;
  }
  
  static VisualPipeline* createPaletteWave(CRGB* fb, uint16_t leds) {
    VisualPipeline* pipe = new VisualPipeline(fb, leds);
    pipe->addStage(new PaletteStage());
    pipe->addStage(new BrightnessStage());
    pipe->addStage(new BlurStage());
    pipe->addStage(new FadeStage());
    return pipe;
  }
};

// ===== CUSTOM EFFECT STAGES =====

// Example: Particle system stage
class ParticleStage : public PipelineStage {
  struct Particle {
    float position;
    float velocity;
    uint8_t life;
    CRGB color;
    bool active;
  };
  
  static const uint8_t MAX_PARTICLES = 10;
  Particle particles[MAX_PARTICLES];
  
public:
  ParticleStage() : PipelineStage("Particles") {
    for (uint8_t i = 0; i < MAX_PARTICLES; i++) {
      particles[i].active = false;
    }
  }
  
  void process(RenderContext& ctx) override {
    if (!enabled) return;
    
    // Spawn new particles
    static uint32_t lastSpawn = 0;
    if (millis() - lastSpawn > 200) {
      spawnParticle(ctx);
      lastSpawn = millis();
    }
    
    // Update and render particles
    for (uint8_t i = 0; i < MAX_PARTICLES; i++) {
      if (!particles[i].active) continue;
      
      Particle& p = particles[i];
      
      // Update physics
      p.position += p.velocity * (ctx.deltaTime * 0.001f);
      p.velocity *= 0.98f; // Drag
      p.life -= 3;
      
      if (p.life == 0 || p.position < 0 || p.position >= ctx.numLeds) {
        p.active = false;
        continue;
      }
      
      // Render
      uint16_t ledIndex = (uint16_t)p.position;
      if (ledIndex < ctx.numLeds) {
        CRGB color = p.color;
        color.fadeToBlackBy(255 - p.life);
        ctx.framebuffer[ledIndex] += color;
      }
    }
  }
  
private:
  void spawnParticle(RenderContext& ctx) {
    for (uint8_t i = 0; i < MAX_PARTICLES; i++) {
      if (!particles[i].active) {
        particles[i].position = random(ctx.numLeds);
        particles[i].velocity = (random(200) - 100) * 0.1f;
        particles[i].life = 255;
        particles[i].color = ColorFromPalette(*ctx.palette, random8());
        particles[i].active = true;
        break;
      }
    }
  }
};

#endif // VISUAL_PIPELINE_H