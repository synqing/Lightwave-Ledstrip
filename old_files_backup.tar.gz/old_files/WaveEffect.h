#ifndef WAVE_EFFECT_H
#define WAVE_EFFECT_H

#include <FastLED.h>
#include "Config.h"
#include "StripMap.h"

// External variables from main sketch
extern CRGB leds[TOTAL_LEDS];
extern uint8_t angles[TOTAL_LEDS];
extern uint8_t radii[TOTAL_LEDS];
extern CRGBPalette16 currentPalette;
extern uint8_t currentPaletteIndex;
extern uint8_t fadeAmount;
extern uint8_t paletteSpeed;

// Wave effect using FastLED's new wave simulator
void displayWaveEffect() {
  static uint16_t waveTime = 0;
  waveTime += 30; // Wave speed
  
  // Apply fadeAmount to create trails
  uint8_t effectiveFade = constrain(fadeAmount, 5, 255);
  fadeToBlackBy(leds, TOTAL_LEDS, effectiveFade);
  
  // Create multiple wave sources along the strip
  for (uint8_t wave = 0; wave < 3; wave++) {
    // Wave parameters
    uint16_t waveCenter = beatsin16(7 + wave * 3, 0, TOTAL_LEDS - 1);
    uint8_t waveHeight = beatsin8(11 + wave * 5, 100, 255);
    uint16_t waveSpeed = waveTime + (wave * 1000);
    
    // Apply wave to LEDs
    for (uint16_t i = 0; i < TOTAL_LEDS; i++) {
      // Calculate distance from wave center
      int16_t distance = abs((int16_t)i - (int16_t)waveCenter);
      
      // Wave function: sin wave that decays with distance
      uint8_t waveValue = 0;
      if (distance < 40) { // Wave radius
        uint8_t decay = map(distance, 0, 40, 255, 0);
        waveValue = (sin16(waveSpeed + (distance * 500)) >> 8) + 128;
        waveValue = scale8(waveValue, decay);
        waveValue = scale8(waveValue, waveHeight);
      }
      
      if (waveValue > 0) {
        // Get color from palette based on wave position
        uint8_t colorIndex = (waveSpeed >> 6) + (wave * 85);
        CRGB color = ColorFromPalette(currentPalette, colorIndex, waveValue);
        
        // Use radii array to modulate brightness
        uint8_t brightness = scale8(waveValue, radii[i]);
        leds[i] += color.nscale8(brightness);
      }
    }
  }
  
  // Debug info
  static uint32_t lastDebugTime = 0;
  if (millis() - lastDebugTime > 2000) {
    Serial.print("[EFFECT] Wave - Fade: ");
    Serial.print(effectiveFade);
    Serial.print(", Speed: ");
    Serial.print(paletteSpeed);
    Serial.print(", Palette: ");
    Serial.println(currentPaletteIndex);
    lastDebugTime = millis();
  }
}

// Kaleidoscope effect inspired by AnimARTrix
void displayKaleidoscopeEffect() {
  static uint16_t kaleidoTime = 0;
  kaleidoTime += paletteSpeed * 10;
  
  // Apply fade
  uint8_t effectiveFade = constrain(fadeAmount, 5, 255);
  fadeToBlackBy(leds, TOTAL_LEDS, effectiveFade);
  
  // Create kaleidoscope patterns
  for (uint16_t i = 0; i < TOTAL_LEDS; i++) {
    // Use angle mapping for kaleidoscope effect
    uint8_t angle = angles[i];
    
    // Multiple layers of rotating patterns
    uint8_t pattern1 = sin8(angle * 3 + (kaleidoTime >> 4));
    uint8_t pattern2 = sin8(angle * 5 - (kaleidoTime >> 3));
    uint8_t pattern3 = cos8(angle * 7 + (kaleidoTime >> 5));
    
    // Combine patterns
    uint8_t combinedPattern = qadd8(qadd8(pattern1 >> 2, pattern2 >> 2), pattern3 >> 1);
    
    // Apply radius-based modulation
    combinedPattern = scale8(combinedPattern, radii[i]);
    
    // Get color from palette
    uint8_t colorIndex = combinedPattern + (kaleidoTime >> 6);
    CRGB color = ColorFromPalette(currentPalette, colorIndex, combinedPattern);
    
    leds[i] = color;
  }
}

// Audio-reactive pulse effect (placeholder - needs audio input)
void displayPulseEffect() {
  static uint8_t pulsePhase = 0;
  pulsePhase += paletteSpeed;
  
  // Simulate audio pulse (in real implementation, this would come from audio input)
  uint8_t pulseBrightness = beatsin8(30, 0, 255);
  uint8_t pulseSize = beatsin8(20, 20, TOTAL_LEDS / 2);
  
  // Apply fade
  fadeToBlackBy(leds, TOTAL_LEDS, fadeAmount);
  
  // Center pulse
  uint16_t center = TOTAL_LEDS / 2;
  
  for (uint16_t i = 0; i < TOTAL_LEDS; i++) {
    int16_t distance = abs((int16_t)i - (int16_t)center);
    
    if (distance < pulseSize) {
      uint8_t brightness = map(distance, 0, pulseSize, pulseBrightness, 0);
      uint8_t colorIndex = pulsePhase + (distance * 4);
      CRGB color = ColorFromPalette(currentPalette, colorIndex, brightness);
      leds[i] += color;
    }
  }
}

#endif // WAVE_EFFECT_H